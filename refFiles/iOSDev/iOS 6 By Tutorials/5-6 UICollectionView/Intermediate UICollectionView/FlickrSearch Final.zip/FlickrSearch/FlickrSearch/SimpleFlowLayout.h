//
//  SimpleFlowLayout.h
//  FlickrSearch
//
//  Created by Fahim Farook on 5/9/12.
//  Copyright (c) 2012 RookSoft Pte. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleFlowLayout : UICollectionViewFlowLayout

@end
