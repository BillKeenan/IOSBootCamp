//
//  FlickrPhotoViewController.h
//  Flickr Search
//
//  Created by Brandon Trebitowski on 7/18/12.
//  Copyright (c) 2012 Brandon Trebitowski. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FlickrPhoto;

@interface FlickrPhotoViewController : UIViewController
@property(nonatomic, strong) FlickrPhoto *flickrPhoto;
@end
