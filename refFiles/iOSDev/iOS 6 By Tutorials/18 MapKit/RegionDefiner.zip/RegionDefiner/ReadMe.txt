
### RegionDefiner ###
 
===========================================================================
DESCRIPTION:
 
An example tool to help generate GeoJSON coverage files for use with the Maps routing apps API
  
===========================================================================
PACKAGING LIST:

AppDelegate
- A basic UIApplication delegate which sets up the application.

ViewController
- A UIViewController subclass which shows a map

MyAnnotation
- Represents a point on the map

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:
 
Version 1.0
- First version.
 
===========================================================================
Copyright (C) 2012 Apple Inc. All rights reserved.