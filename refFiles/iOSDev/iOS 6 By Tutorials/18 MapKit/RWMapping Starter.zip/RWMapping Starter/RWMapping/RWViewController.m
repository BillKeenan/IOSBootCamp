//
//  RWViewController.m
//  RWMapping
//
//  Created by Matt Galloway on 23/06/2012.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "RWViewController.h"

#import <MapKit/MapKit.h>

@interface RWViewController () <MKMapViewDelegate> {
}

typedef NS_ENUM(NSInteger, RWMapMode) {
    RWMapModeNormal = 0,
    RWMapModeLoading,
    RWMapModeDirections,
};

@property (nonatomic, weak) IBOutlet MKMapView *mapView;
@property (nonatomic, assign) RWMapMode mapMode;
@end

@implementation RWViewController

- (void)setMapMode:(RWMapMode)mapMode {
    _mapMode = mapMode;
    
    switch (mapMode) {
        case RWMapModeNormal: {
            self.title = @"Maps";
        }
            break;
        case RWMapModeLoading: {
            self.title = @"Loading...";
        }
            break;
        case RWMapModeDirections: {
            self.title = @"Directions";
        }
            break;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
