//
//  RWAppDelegate.h
//  RWMapping
//
//  Created by Matt Galloway on 23/06/2012.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
