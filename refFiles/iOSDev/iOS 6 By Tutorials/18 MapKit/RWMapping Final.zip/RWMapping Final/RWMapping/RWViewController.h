//
//  RWViewController.h
//  RWMapping
//
//  Created by Matt Galloway on 23/06/2012.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface RWViewController : UIViewController

- (void)routeFrom:(CLLocationCoordinate2D)from to:(CLLocationCoordinate2D)to;
- (void)routeFromCurrentLocationTo:(CLLocationCoordinate2D)to;
- (void)routeToCurrentLocationFrom:(CLLocationCoordinate2D)from;

@end
