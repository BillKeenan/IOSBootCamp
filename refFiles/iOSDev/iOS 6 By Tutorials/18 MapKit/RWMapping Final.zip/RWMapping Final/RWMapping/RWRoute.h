//
//  RWRoute.h
//  RWMapping
//
//  Created by Matt Galloway on 24/06/2012.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@class RWStation;

@interface RWRoute : NSObject

@property (nonatomic, strong) RWStation *fromStation;
@property (nonatomic, strong) RWStation *toStation;
@property (nonatomic, strong) MKPolyline *mapPolyline;

@end
