//
//  HMStoreDetailViewController.h
//  Hangman
//
//  Created by Ray Wenderlich on 7/12/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

@interface HMStoreDetailViewController : UIViewController

@end
