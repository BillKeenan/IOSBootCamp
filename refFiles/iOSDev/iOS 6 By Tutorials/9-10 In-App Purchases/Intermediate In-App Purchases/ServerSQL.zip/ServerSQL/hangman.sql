CREATE DATABASE IF NOT EXISTS hangman;
USE hangman;

CREATE TABLE `transactions` (
  `transaction_id` char(32) NOT NULL,
  `product_id` char(32) NOT NULL,
  `original_transaction_id` char(32) NOT NULL,
  `validation_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;