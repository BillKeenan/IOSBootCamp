//
//  IAPHelper.m
//  Hangman
//
//  Created by Ray Wenderlich on 9/17/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "IAPHelper.h"
#import <StoreKit/StoreKit.h>
#import "IAPProduct.h"
#import "VerificationController.h"

@interface IAPHelper () <SKProductsRequestDelegate, SKPaymentTransactionObserver>
@end

@implementation IAPHelper {
    SKProductsRequest * _productsRequest;
    RequestProductsCompletionHandler _completionHandler;
}

- (id)initWithProducts:(NSMutableDictionary *)products {
    if ((self = [super init])) {
        _products = products;
        [[SKPaymentQueue defaultQueue]
         addTransactionObserver:self];
    }
    return self;
}

- (void)requestProductsWithCompletionHandler:(RequestProductsCompletionHandler)completionHandler {
    
    // 1
    _completionHandler = [completionHandler copy];
    
    // 2
    NSMutableSet * productIdentifiers =
    [NSMutableSet setWithCapacity:_products.count];
    for (IAPProduct * product in _products.allValues) {
        product.availableForPurchase = NO;
        [productIdentifiers
         addObject:product.productIdentifier];
    }
    
    // 3
    _productsRequest = [[SKProductsRequest alloc]
                        initWithProductIdentifiers:productIdentifiers];
    _productsRequest.delegate = self;
    [_productsRequest start];
    
}

#pragma mark - SKProductsRequestDelegate

- (void)productsRequest:(SKProductsRequest *)request
     didReceiveResponse:(SKProductsResponse *)response {
    
    NSLog(@"Loaded list of products...");
    _productsRequest = nil;
    
    // 1
    NSArray * skProducts = response.products;
    for (SKProduct * skProduct in skProducts) {
        IAPProduct * product =
        _products[skProduct.productIdentifier];
        product.skProduct = skProduct;
        product.availableForPurchase = YES;
    }
    
    // 2
    for (NSString * invalidProductIdentifier in
         response.invalidProductIdentifiers) {
        IAPProduct * product =
        _products[invalidProductIdentifier];
        product.availableForPurchase = NO;
        NSLog(@"Invalid product identifier, removing: %@",
              invalidProductIdentifier);
    }
    
    // 3
    NSMutableArray * availableProducts = [NSMutableArray array];
    for (IAPProduct * product in _products.allValues) {
        if (product.availableForPurchase) {
            [availableProducts addObject:product];
        }
    }
    
    _completionHandler(YES, availableProducts);
    _completionHandler = nil;
    
}

- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    
    NSLog(@"Failed to load list of products.");
    _productsRequest = nil;
    
    // 5
    _completionHandler(FALSE, nil);
    _completionHandler = nil;
    
}

- (void)buyProduct:(IAPProduct *)product {
    
    NSAssert(product.allowedToPurchase, @"This product isn't allowed to be purchased!");
    
    NSLog(@"Buying %@...", product.productIdentifier);
    
    product.purchaseInProgress = YES;
    SKPayment * payment = [SKPayment
                           paymentWithProduct:product.skProduct];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
    
}

- (void)paymentQueue:(SKPaymentQueue *)queue
 updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction * transaction in transactions) {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
            default:
                break;
        }
    };
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"completeTransaction...");
    [self validateReceiptForTransaction:transaction];
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"restoreTransaction...");
    [self validateReceiptForTransaction:transaction];
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    
    NSLog(@"failedTransaction...");
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        NSLog(@"Transaction error: %@",
              transaction.error.localizedDescription);
    }
    
    IAPProduct * product =
    _products[transaction.payment.productIdentifier];
    [self notifyStatusForProductIdentifier:
     transaction.payment.productIdentifier
                                    string:@"Purchase failed."];
    product.purchaseInProgress = NO;
    [[SKPaymentQueue defaultQueue]
     finishTransaction: transaction];
    
}

- (void)notifyStatusForProductIdentifier:
(NSString *)productIdentifier string:(NSString *)string {
    IAPProduct * product = _products[productIdentifier];
    [self notifyStatusForProduct:product string:string];
}

- (void)notifyStatusForProduct:(IAPProduct *)product
                        string:(NSString *)string {
    
}

- (void)provideContentForTransaction:
(SKPaymentTransaction *)transaction
                   productIdentifier:(NSString *)productIdentifier {
    
    IAPProduct * product = _products[productIdentifier];
    
    [self provideContentForProductIdentifier:productIdentifier];
    [self notifyStatusForProductIdentifier:productIdentifier
                                    string:@"Purchase complete!"];
    
    product.purchaseInProgress = NO;
    [[SKPaymentQueue defaultQueue] finishTransaction:
     transaction];
    
}

- (void)provideContentForProductIdentifier:
(NSString *)productIdentifier {
    
}

- (void)restoreCompletedTransactions {
    [[SKPaymentQueue defaultQueue]
     restoreCompletedTransactions];
}

- (void)validateReceiptForTransaction:
(SKPaymentTransaction *)transaction {
    
    IAPProduct * product =
    _products[transaction.payment.productIdentifier];
    VerificationController * verifier =
    [VerificationController sharedInstance];
    
    [verifier verifyPurchase:transaction
           completionHandler:^(BOOL success) {
               if (success) {
                   NSLog(@"Successfully verified receipt!");
                   [self provideContentForTransaction:transaction
                                    productIdentifier:
                    transaction.payment.productIdentifier];
               } else {
                   NSLog(@"Failed to validate receipt.");
                   product.purchaseInProgress = NO;
                   [[SKPaymentQueue defaultQueue]
                    finishTransaction: transaction];
               }
           }];
    
}
@end
