//
//  HMMusicInfo.h
//  Hangman
//
//  Created by Ray Wenderlich on 9/17/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMMusicInfo : NSObject

@property (nonatomic, assign) int trackId;
@property (nonatomic, strong) NSString * trackName;
@property (nonatomic, strong) NSString * artistName;
@property (nonatomic, assign) float price;
@property (nonatomic, strong) NSString * artworkURL;

- (id)initWithTrackId:(int)trackId
            trackName:(NSString *)trackName
           artistName:(NSString *)artistName price:(float)price
           artworkURL:(NSString *)artworkURL;

@end
