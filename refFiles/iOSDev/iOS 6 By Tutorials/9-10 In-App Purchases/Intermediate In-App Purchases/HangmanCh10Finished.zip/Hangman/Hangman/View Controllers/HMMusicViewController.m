//
//  HMMusicViewController.m
//  Hangman
//
//  Created by Ray Wenderlich on 9/17/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "HMMusicViewController.h"
#import "AFHTTPClient.h"
#import "AFHTTPRequestOperation.h"
#import "HMMusicInfo.h"
#import "HMMusicCell.h"
#import "UIImageView+AFNetworking.h"
#import "MBProgressHUD.h"
#import <StoreKit/StoreKit.h>

@interface HMMusicViewController ()
<SKStoreProductViewControllerDelegate>
@end

@implementation HMMusicViewController {
    NSMutableArray * _musicInfos;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(reload)
                  forControlEvents:UIControlEventValueChanged];
    [self reload];
    [self.refreshControl beginRefreshing];
    
}

- (void)reload {
    _musicInfos = [NSMutableArray array];
    [self.tableView reloadData];
    [self requestMusic];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _musicInfos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    HMMusicCell *cell = [tableView
                         dequeueReusableCellWithIdentifier:CellIdentifier
                         forIndexPath:indexPath];
    
    HMMusicInfo * info = [_musicInfos
                          objectAtIndex:indexPath.row];
    
    cell.titleLabel.text = info.trackName;
    cell.descriptionLabel.text = info.artistName;
    cell.priceLabel.text = [NSString stringWithFormat:@"$%0.2f",
                            info.price];
    [cell.iconImageView setImageWithURL:[NSURL
                                         URLWithString:info.artworkURL] placeholderImage:[UIImage
                                                                                          imageNamed:@"icon_placeholder.png"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HMMusicInfo * info = [_musicInfos
                          objectAtIndex:indexPath.row];
    
    MBProgressHUD * hud = [MBProgressHUD
                           showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"Loading...";
    
    SKStoreProductViewController * viewController =
    [[SKStoreProductViewController alloc] init];
    viewController.delegate = self;
    NSDictionary * parameters =
    @{SKStoreProductParameterITunesItemIdentifier: [NSNumber
                                                    numberWithInt:info.trackId]};
    
    [viewController loadProductWithParameters:parameters
                              completionBlock:^(BOOL result, NSError *error) {
                                  [MBProgressHUD hideHUDForView:self.view animated:YES];
                                  if (result) {
                                      [self presentViewController:viewController
                                                         animated:YES completion:nil];
                                  } else {
                                      NSLog(@"Failed to load product: %@", error);
                                  }
                              }];
    
}

- (void)productViewControllerDidFinish:
(SKStoreProductViewController *)viewController {
    NSLog(@"Finished shopping!");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)requestMusic {
    
    // 1
    NSURL * url = [NSURL
                   URLWithString:@"http://itunes.apple.com/"];
    AFHTTPClient * client = [[AFHTTPClient alloc]
                             initWithBaseURL:url];
    NSDictionary * parameters = @{
    @"term" : @"castlevania",
    @"media" : @"music",
    @"entity" : @"musicTrack",
    @"attribute" : @"songTerm"
    };
    [client getPath:@"/search" parameters:parameters
            success:^(AFHTTPRequestOperation *operation, id
                      responseObject) {
                // 2
                NSError * error;
                NSDictionary * searchResults = [NSJSONSerialization
                                                JSONObjectWithData:operation.responseData options:0
                                                error:&error];
                if (searchResults == nil) {
                    NSLog(@"Failure parsing response: %@.", error);
                } else {
                    // 3
                    NSArray * results = searchResults[@"results"];
                    for (NSDictionary * result in results) {
                        int trackId = [result[@"trackId"] intValue];
                        NSString * trackName = result[@"trackName"];
                        NSString * artistName = result[@"artistName"];
                        float price = [result[@"trackPrice"]
                                       floatValue];
                        NSString * artworkURL = result[@"artworkUrl60"];
                        
                        // 4
                        HMMusicInfo * musicInfo = [[HMMusicInfo alloc]
                                                   initWithTrackId:trackId trackName:trackName
                                                   artistName:artistName price:price
                                                   artworkURL:artworkURL];
                        [_musicInfos addObject:musicInfo];
                    }
                    
                    // 5
                    [self.tableView reloadData];
                }
                [self.refreshControl endRefreshing];
            } failure:^(AFHTTPRequestOperation *operation, 
                        NSError *error) {
                NSLog(@"Error searching for songs: %@", error);
                [self.refreshControl endRefreshing];
            }];
    
}


@end
