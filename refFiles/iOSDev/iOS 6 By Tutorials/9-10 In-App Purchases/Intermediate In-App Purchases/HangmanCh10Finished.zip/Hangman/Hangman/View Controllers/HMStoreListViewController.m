//
//  HMStoreListViewController.m
//  Hangman
//
//  Created by Ray Wenderlich on 7/12/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "HMStoreListViewController.h"
#import "HMStoreListViewCell.h"
#import "HMIAPHelper.h"
#import "IAPProduct.h"
#import <StoreKit/StoreKit.h>
#import "HMStoreDetailViewController.h"
#import "IAPProductInfo.h"
#import "IAPProductPurchase.h"
#import "UIImageView+AFNetworking.h"
#import "MBProgressHUD.h"

@interface HMStoreListViewController() <UIAlertViewDelegate, SKStoreProductViewControllerDelegate>
@end

@implementation HMStoreListViewController {
    NSArray * _products;
    NSNumberFormatter * _priceFormatter;
    BOOL _observing;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(doneTapped:)];
    }
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Restore" style:UIBarButtonItemStyleBordered target:self action:@selector(restoreTapped:)];

    _priceFormatter = [[NSNumberFormatter alloc] init];
    [_priceFormatter
     setFormatterBehavior:NSNumberFormatterBehavior10_4];
    [_priceFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(reload)
                  forControlEvents:UIControlEventValueChanged];
    [self reload];
    [self.refreshControl beginRefreshing];
    
}

- (void)reload {
    [self setProducts:nil];
    [self.tableView reloadData];
    [[HMIAPHelper sharedInstance] requestProductsWithCompletionHandler:^(BOOL success, NSArray *products) {
        if (success) {
            [self setProducts:products];
            [self.tableView reloadData];
        }
        [self.refreshControl endRefreshing];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self addObservers];
    [self.tableView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self removeObservers];
}

#pragma mark - KVO

- (void)addObservers {
    if (_observing || _products == nil) return;
    _observing = TRUE;
    for (IAPProduct * product in _products) {
        [product addObserver:self
                  forKeyPath:@"purchaseInProgress" options:0 context:nil];
        [product addObserver:self forKeyPath:@"purchase"
                     options:0 context:nil];
        [product addObserver:self forKeyPath:@"progress"
                     options:0 context:nil];
    }
}

- (void)removeObservers {
    if (!_observing) return;
    _observing = FALSE;
    for (IAPProduct * product in _products) {
        [product removeObserver:self
                     forKeyPath:@"purchaseInProgress" context:nil];
        [product removeObserver:self forKeyPath:@"purchase"
                        context:nil];
        [product removeObserver:self forKeyPath:@"progress"
                        context:nil];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object change:(NSDictionary *)change
                       context:(void *)context {
    IAPProduct * product = (IAPProduct *)object;
    int row = [_products indexOfObject:product];
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:row
                                                 inSection:0];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath]
                          withRowAnimation:UITableViewRowAnimationNone];
}

- (void)setProducts:(NSArray *)products {    
    [self removeObservers];
    _products = products;
    [self addObservers];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    return _products.count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    HMStoreListViewCell *cell = [tableView
                                 dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (indexPath.row < _products.count) {
        
        // Put old code here . . .
        IAPProduct *product = _products[indexPath.row];
        
        cell.titleLabel.text = product.skProduct.localizedTitle;
        cell.descriptionLabel.text =
        product.skProduct.localizedDescription;
        [_priceFormatter setLocale:product.skProduct.priceLocale];
        
        if (product.purchaseInProgress) {
            cell.priceLabel.text = @"Installing...";
        } else if (!product.purchase.consumable && product.purchase) {
            if (product.skProduct.downloadContentVersion &&
                ![product.skProduct.downloadContentVersion
                  isEqualToString:product.purchase.contentVersion]) {
                    cell.priceLabel.text = @"Update";
                } else {
                    cell.priceLabel.text = @"Installed";
                }
        } else if (product.allowedToPurchase) {
            cell.priceLabel.text = [_priceFormatter
                                    stringFromNumber:product.skProduct.price];
        } else {
            NSLog(@"Unexpected product state!");
            cell.priceLabel.text = @"";
        }
        
        if (product.skDownload.downloadState == SKDownloadStateActive) {
            cell.descriptionLabel.hidden = YES;
            cell.progressView.hidden = NO;
            cell.progressView.progress = product.progress;
        } else {
            cell.descriptionLabel.hidden = NO;
            cell.progressView.hidden = YES;
        }
        
        [cell.iconImageView setImageWithURL:
         [NSURL URLWithString:product.info.icon]
                           placeholderImage:
         [UIImage imageNamed:@"icon_placeholder.png"]];
        
    } else {
        
        cell.iconImageView.image = [UIImage imageNamed:@"icon_music.png"];
        cell.titleLabel.text = @"Game Music";
        cell.descriptionLabel.text = @"Get some great music for the game!";
        cell.priceLabel.text = @"Various";
        cell.descriptionLabel.hidden = NO;
        cell.progressView.hidden = YES;
        
    }
    
    return cell;
}

#pragma mark - Callbacks

- (void)doneTapped:(id)sender {
}

- (void)restoreTapped:(id)sender {
    NSLog(@"Restore tapped!");
    UIAlertView * alertView = [[UIAlertView alloc]
                               initWithTitle:@"Restore Content"
                               message:@"Would you like to check for and restore any previous purchases?"
                               delegate:self
                               cancelButtonTitle:@"Cancel"
                               otherButtonTitles:@"OK", nil];
    alertView.delegate = self;
    [alertView show];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView
didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (buttonIndex == alertView.firstOtherButtonIndex) {
        [[HMIAPHelper sharedInstance] 
         restoreCompletedTransactions];
    }
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < _products.count) {
        [self performSegueWithIdentifier:@"PushDetail"
                                  sender:indexPath];
    } else {
        //[self showMusicStore];
        [self performSegueWithIdentifier:@"PushMusic"
                                  sender:indexPath];
    }
}

#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue
                 sender:(id)sender {
    if ([segue.identifier isEqualToString:@"PushDetail"]) {
        HMStoreDetailViewController * detailViewController =
        (HMStoreDetailViewController *)
        segue.destinationViewController;
        NSIndexPath * indexPath = (NSIndexPath *)sender;
        IAPProduct *product = _products[indexPath.row];
        detailViewController.product = product;
    }
}

#pragma mark - Music Store

- (void)showMusicStore {
    
    // 1
    MBProgressHUD * hud = [MBProgressHUD
                           showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"Loading...";
    
    // 2
    SKStoreProductViewController * viewController =
    [[SKStoreProductViewController alloc] init];
    viewController.delegate = self;
    
    // 3
    NSDictionary * parameters =
    @{SKStoreProductParameterITunesItemIdentifier:
    @286201200};
    [viewController loadProductWithParameters:parameters
                              completionBlock:^(BOOL result, NSError *error) {
                                  [MBProgressHUD hideHUDForView:self.view animated:YES];
                                  if (result) {
                                      // 4
                                      [self presentViewController:viewController
                                                         animated:YES completion:nil];
                                  } else {
                                      NSLog(@"Failed to load products: %@", error);
                                  }
                              }];
    
}

- (void)productViewControllerDidFinish:(SKStoreProductViewController *)viewController {
    // 5
    NSLog(@"Finished shopping!");
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
