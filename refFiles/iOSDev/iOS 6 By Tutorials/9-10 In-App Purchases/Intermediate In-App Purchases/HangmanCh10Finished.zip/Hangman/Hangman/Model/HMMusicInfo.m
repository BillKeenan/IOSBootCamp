//
//  HMMusicInfo.m
//  Hangman
//
//  Created by Ray Wenderlich on 9/17/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "HMMusicInfo.h"

@implementation HMMusicInfo

- (id)initWithTrackId:(int)trackId
            trackName:(NSString *)trackName
           artistName:(NSString *)artistName price:(float)price
           artworkURL:(NSString *)artworkURL {
    if ((self = [super init])) {
        self.trackId = trackId;
        self.trackName = trackName;
        self.artistName = artistName;
        self.price = price;
        self.artworkURL = artworkURL;
    }
    return self;
}

@end
