//
//  HMIAPHelper.h
//  Hangman
//
//  Created by Ray Wenderlich on 9/17/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "IAPHelper.h"

@interface HMIAPHelper : IAPHelper

+ (HMIAPHelper *)sharedInstance;

@end
