//
// From Jody Hagins
// http://stackoverflow.com/questions/10091816/nsfilesystemfreesize-translating-result-into-user-friendly-display-of-mb-gb
//

#import <Foundation/Foundation.h>

NSString* prettyBytes(uint64_t numBytes);
