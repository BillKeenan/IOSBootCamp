//
//  FileListViewController.m
//  rtf1
//
//  Created by Marin Todorov on 08/08/2012.
//  Copyright (c) 2012 Marin Todorov. All rights reserved.
//

#import "FileListViewController.h"
#import "ViewController.h"
#import "NSObject+AutoCoding.h"

@interface FileListViewController () {
    NSArray* fileList;
	NSMutableDictionary* renderedStrings;
}

@end

@implementation FileListViewController

-(void)viewDidLoad {
    renderedStrings = [NSMutableDictionary
					   dictionaryWithCapacity:5];
}

-(void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	[self loadFileList];
	self.title = [NSString stringWithFormat:@"Fancy Notes (%i)",
				  fileList.count];
	[self.tableView reloadData];
}

-(void)loadFileList {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(
														 NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    fileList = [fm contentsOfDirectoryAtPath:documentsDirectory
                                       error:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return fileList.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(
														 NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString* filePath = [documentsDirectory
						  stringByAppendingPathComponent: fileList[indexPath.row]];
	
    NSAttributedString* contents = [NSAttributedString objectWithContentsOfFile: filePath];
	contents = [contents attributedSubstringFromRange:
				NSMakeRange(0, MIN(30, contents.length))
				];
	NSMutableAttributedString* mContents =
	[[NSMutableAttributedString alloc]
	 initWithAttributedString:contents];
	
	NSAttributedString* dots = [[NSAttributedString alloc] initWithString:@"..."];
    
	[mContents appendAttributedString: dots];
	CGRect bounds = [mContents
					 boundingRectWithSize:CGSizeMake(300, 10000)
					 options:NSStringDrawingUsesLineFragmentOrigin
					 context:nil];
	UIGraphicsBeginImageContextWithOptions(bounds.size, NO, 0.0);
    
	[mContents drawWithRect:bounds
					options:NSStringDrawingUsesLineFragmentOrigin
					context:nil];
    
	UIImage *renderedText =
	UIGraphicsGetImageFromCurrentImageContext();
	
	UIGraphicsEndImageContext();
	renderedStrings[fileList[indexPath.row]] = renderedText;
	
	return bounds.size.height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    //configure the cell...
	cell.textLabel.text = nil;
	cell.imageView.image = renderedStrings[fileList[indexPath.row]];
    return cell;
}

#pragma mark - Table view delegate

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	if ([segue.identifier compare:@"AddButton"]==NSOrderedSame) {
		ViewController* screen = segue.destinationViewController;
		
		NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]
										  init];
		[dateFormatter setDateStyle:NSDateFormatterMediumStyle];
		[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
        
		NSString *dateString = [dateFormatter stringFromDate:
								[NSDate date]];
        
		NSString* fileName = [documentsDirectory stringByAppendingPathComponent: [NSString stringWithFormat:@"%@.plist", dateString]];
        
		//create a new note
		screen.fileName = fileName;
		
		return;
	}
	if ([segue.identifier compare:@"Edit"]==NSOrderedSame) {
		//1
		ViewController* screen = segue.destinationViewController;
		
		//2
		int selectedIndex = [self.tableView indexPathForSelectedRow].row;
		
		//3
		NSString* selectedFileName = fileList[selectedIndex];
		
		//4
		screen.fileName = [documentsDirectory stringByAppendingPathComponent:selectedFileName];
		
		return;
	}
}

@end
