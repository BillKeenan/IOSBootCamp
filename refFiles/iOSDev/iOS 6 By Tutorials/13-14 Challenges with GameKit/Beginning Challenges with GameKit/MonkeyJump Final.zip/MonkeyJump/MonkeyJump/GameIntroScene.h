//
//  GameIntroScene.h
//  MonkeyJump
//
//  Created by Kauserali on 02/08/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

@interface GameIntroScene : CCScene
@end
