//
//  HelperMethods.h
//  MonkeyJump
//
//  Created by Fahim Farook on 18/8/12.
//
//

#import <Foundation/Foundation.h>

@interface HelperMethods : NSObject

+(void)reportAchievementsForDistance:(int64_t) distance;

@end
