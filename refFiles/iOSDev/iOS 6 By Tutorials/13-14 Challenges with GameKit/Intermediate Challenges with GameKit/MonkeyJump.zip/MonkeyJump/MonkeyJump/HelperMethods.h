//
//  HelperMethods.h
//  MonkeyJump
//
//  Created by Kauserali on 01/08/12.
//
//

@interface HelperMethods : NSObject
+(void) reportAchievementsForDistance:
        (int64_t) distance;
@end
