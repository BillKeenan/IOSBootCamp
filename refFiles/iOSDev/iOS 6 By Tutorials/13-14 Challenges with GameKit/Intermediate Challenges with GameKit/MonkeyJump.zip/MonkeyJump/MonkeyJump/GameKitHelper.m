//
//  GameKitHelper.m
//  MonkeyJump
//
//  Created by Kauserali on 02/08/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "GameKitHelper.h"
#import "GameConstants.h"
#import "GameTrackingObj.h"
#import "GameTrackingEngine.h"
#import "GameScene.h"
#import "FriendsPickerViewController.h"
#import "ChallengesPickerViewController.h"

@interface GameKitHelper ()
        <GKGameCenterControllerDelegate> {
    BOOL _gameCenterFeaturesEnabled;
}
@end

@implementation GameKitHelper

#pragma mark Singleton stuff

+(id) sharedGameKitHelper {
    static GameKitHelper *sharedGameKitHelper;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedGameKitHelper = [[GameKitHelper alloc] init];
    });
    return sharedGameKitHelper;
}

#pragma mark Init & Dealloc

-(id) init {
	if ((self = [super init])) {
        _includeLocalPlayerScore = NO;
	}
	return self;
}

#pragma mark UIViewController stuff

-(UIViewController*) getRootViewController {
	return [UIApplication sharedApplication].keyWindow.rootViewController;
}

-(void) presentViewController:(UIViewController*)vc {
	UIViewController* rootVC = [self getRootViewController];
	[rootVC presentViewController:vc animated:YES completion:nil];
}

-(void) dismissModalViewController {
    UIViewController* rootVC = [self getRootViewController];
    [rootVC dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark setLastError

-(void) setLastError:(NSError*)error {
    _lastError = [error copy];
	if (_lastError) {
		NSLog(@"GameKitHelper ERROR: %@", [[_lastError userInfo] description]);
	}
}

#pragma mark Player Authentication

-(void) authenticateLocalPlayer {
    
	GKLocalPlayer* localPlayer =
            [GKLocalPlayer localPlayer];
    
    localPlayer.authenticateHandler =
            ^(UIViewController *viewController,
              NSError *error) {
        
        [self setLastError:error];
        
        if ([CCDirector sharedDirector].isPaused)
            [[CCDirector sharedDirector] resume];
        
        if (localPlayer.authenticated) {
            _gameCenterFeaturesEnabled = YES;
            [self loadAchievements];
        } else if(viewController) {
            [[CCDirector sharedDirector] pause];
            [self presentViewController:viewController];
        } else {
            _gameCenterFeaturesEnabled = NO;
        }
    };
}

#pragma mark Scores & Leaderboard

-(void) submitScore:(int64_t)score
        category:(NSString*)category {
    //1: Check if game center
    //   features are enabled
    if (!_gameCenterFeaturesEnabled) {
        CCLOG(@"Player not authenticated");
        return;
    }
    
    //2: Create a GKScore object
	GKScore* gkScore =
            [[GKScore alloc]
                initWithCategory:category];
    
    //3: Set the score value
	gkScore.value = score;
    
    //4: Send the score to game center
	[gkScore reportScoreWithCompletionHandler:
                           ^(NSError* error) {
                               
        [self setLastError:error];

        BOOL success = (error == nil);
                               
        if ([_delegate
                respondsToSelector:
                @selector(onScoresSubmitted:)]) {
            
            [_delegate onScoresSubmitted:success];
        }
     }];
}

#pragma mark Achievements

-(void) loadAchievements {

    //1    
    if (!_gameCenterFeaturesEnabled) {
        CCLOG(@"Player not authenticated");
        return;
    }
	
    //2
    [GKAchievement
     loadAchievementsWithCompletionHandler:
        ^(NSArray* loadedAchievements, NSError* error) {
            
         [self setLastError:error];
		 
         if (_achievements == nil) {
             _achievements =
                [[NSMutableDictionary alloc] init];
         } else {
             [_achievements removeAllObjects];
         }
         
         for (GKAchievement* achievement
                    in loadedAchievements) {
             achievement.showsCompletionBanner = YES;
             _achievements[achievement.identifier]
                                        = achievement;
         }
         if ([_delegate respondsToSelector:
                    @selector(onAchievementsLoaded:)]) {
             [_delegate
                    onAchievementsLoaded:_achievements];
         }
     }];
}

-(GKAchievement*) getAchievementByID:
                (NSString*)identifier {
    
    //1
	GKAchievement* achievement =
            _achievements[identifier];
    
    //2
	if (achievement == nil) {
		// Create a new achievement object
		achievement = [[GKAchievement alloc]
                       initWithIdentifier:identifier];
        achievement.showsCompletionBanner = YES;
		_achievements[achievement.identifier]
                                = achievement;
	}
	return achievement;
}

-(void) reportAchievementWithID:
        (NSString*)identifier
                percentComplete:(float)percent {
    //1
    if (!_gameCenterFeaturesEnabled) {
        CCLOG(@"Player not authenticated");
        return;
    }
    
    //2
	GKAchievement* achievement =
        [self getAchievementByID:identifier];
    
    //3
	if (achievement != nil
        && achievement.percentComplete < percent) {
        
		achievement.percentComplete = percent;
        
		[achievement
            reportAchievementWithCompletionHandler:
            ^(NSError* error) {
                
            [self setLastError:error];
                
            if ([_delegate
                 respondsToSelector:
                 @selector(onAchievementReported:)]) {
                [_delegate
                 onAchievementReported:achievement];
            }
         }];
	}
}

-(void) resetAchievements {
    if (!_gameCenterFeaturesEnabled) {
        CCLOG(@"Player not authenticated");
        return;
    }
	[_achievements removeAllObjects];
	[GKAchievement resetAchievementsWithCompletionHandler:^(NSError* error) {
        [self setLastError:error];
        BOOL success = (error == nil);
        if ([_delegate respondsToSelector:@selector(onResetAchievements:)]) {
            [_delegate onResetAchievements:success];
        }
     }];
}

#pragma mark score share method

-(void) shareScore:(int64_t)score
         catergory:(NSString*)category {
    //1
    GKScore* gkScore =
        [[GKScore alloc]
         initWithCategory:category];
    
    gkScore.value = score;
    
    //2
    UIActivityViewController
    *activityViewController =
            [[UIActivityViewController alloc]
             initWithActivityItems:@[gkScore]
             applicationActivities:nil];
    
    //3
    activityViewController.completionHandler =
    ^(NSString *activityType, BOOL completed) {
        
        if (completed)
            [self dismissModalViewController];
    };
    
    //4
    [self presentViewController:
            activityViewController];
}

#pragma mark Game center UI method

-(void) showGameCenterViewController {
    //1
    GKGameCenterViewController *gameCenterViewController
            = [[GKGameCenterViewController alloc] init];
    
    //2
    gameCenterViewController.gameCenterDelegate = self;
    
    //3
    gameCenterViewController.viewState
            = GKGameCenterViewControllerStateDefault;
    
    //4
    [self presentViewController:gameCenterViewController];
}

#pragma mark GKGameCenterControllerDelegate method

- (void)gameCenterViewControllerDidFinish:
        (GKGameCenterViewController *)gameCenterViewController {
    
    [self dismissModalViewController];
}

// Method to show friends picker
-(void)
    showFriendsPickerViewControllerForScore:
    (int64_t)score gameTrackObj:(GameTrackingObj*) gameTrackObj {
    
    FriendsPickerViewController
        *friendsPickerViewController =
                [[FriendsPickerViewController alloc]
                 initWithScore:score gameTrackObj:gameTrackObj];
    
    friendsPickerViewController.
        cancelButtonPressedBlock = ^() {
        [self dismissModalViewController];
    };
    
    friendsPickerViewController.
        challengeButtonPressedBlock = ^() {
        [self dismissModalViewController];
    };
    
    UINavigationController *navigationController =
        [[UINavigationController alloc]
            initWithRootViewController:
            friendsPickerViewController];
    
    [self presentViewController:navigationController];
}

// Method to show the challenge picker
-(void) showChallengePickerViewController {
    ChallengesPickerViewController *challengesPickerViewController = [[ChallengesPickerViewController alloc] initWithNibName:@"ChallengesPickerViewController" bundle:nil];
    
    challengesPickerViewController.cancelButtonPressedBlock = ^() {
        [self dismissModalViewController];
    };
    
    challengesPickerViewController.challengeSelectedBlock = ^(GKScoreChallenge *challenge) {
        [self dismissModalViewController];
        
        if (challenge.score.context != 0) {
            //valid challenge id
            [[GameTrackingEngine sharedClient]
             retrieveGameTrackingDetailsForKey:challenge.score.context
             onSuccess:^(GameTrackingObj *gameTrackingObj){
                 
                 [[CCDirector sharedDirector]
                  replaceScene:[CCTransitionProgressRadialCCW
                                transitionWithDuration:1.0f
                                scene:[[GameScene alloc] initWithGameTrackingObj:gameTrackingObj]]];
             } onFailure:^(NSError *error){
                 [[CCDirector sharedDirector]
                  replaceScene:[CCTransitionProgressRadialCCW
                                transitionWithDuration:1.0f
                                scene:[[GameScene alloc] init]]];
             }];
        } else {
            //some error might have occurred
            [[CCDirector sharedDirector]
             replaceScene:[CCTransitionProgressRadialCCW
                           transitionWithDuration:1.0f
                           scene:[[GameScene alloc] init]]];
        }
    };
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:challengesPickerViewController];
    [self presentViewController:navigationController];
}

// Method used to find friends who are playing a similar game and their scores
-(void) findScoresOfFriendsToChallenge {
    //1
    GKLeaderboard *leaderboard =
            [[GKLeaderboard alloc] init];
    
    //2
    leaderboard.category =
            kHighScoreLeaderboardCategory;
    
    //3
    leaderboard.playerScope =
            GKLeaderboardPlayerScopeFriendsOnly;
    
    //4
    leaderboard.range = NSMakeRange(1, 100);
    
    //5
    [leaderboard
        loadScoresWithCompletionHandler:
        ^(NSArray *scores, NSError *error) {
            
        [self setLastError:error];
            
        BOOL success = (error == nil);
            
        if (success) {
            if (!_includeLocalPlayerScore) {
                NSMutableArray *friendsScores =
                        [NSMutableArray array];
                
                for (GKScore *score in scores) {
                    if (![score.playerID
                          isEqualToString:
                          [GKLocalPlayer localPlayer]
                          .playerID]) {
                        [friendsScores addObject:score];
                    }
                }
                scores = friendsScores;
            }
            if ([_delegate
                 respondsToSelector:
                 @selector
                 (onScoresOfFriendsToChallengeListReceived:)]) {
                [_delegate
                 onScoresOfFriendsToChallengeListReceived:scores];
            }
        }
    }];
}

-(void) getPlayerInfo:(NSArray*)playerList {
    //1
	if (_gameCenterFeaturesEnabled == NO)
		return;
    
    //2
	if ([playerList count] > 0) {
		[GKPlayer
         loadPlayersForIdentifiers:
         playerList
         withCompletionHandler:
         ^(NSArray* players, NSError* error) {
             
            [self setLastError:error];
             
            if ([_delegate
                 respondsToSelector:
                 @selector(onPlayerInfoReceived:)]) {
                
                [_delegate onPlayerInfoReceived:players];
            }
         }];
	}
}

-(void) sendScoreChallengeToPlayers:
    (NSArray*)players
    withScore:(int64_t)score
    message:(NSString*)message {
    [self sendScoreChallengeToPlayers:players withScore:score message:message withGameTrackingObj:nil];
}

-(void) sendScoreChallengeToPlayers:
    (NSArray *)players
    withScore:(int64_t)score
    message:(NSString *)message
    withGameTrackingObj:(GameTrackingObj*)gameTrackingObj {
    
    if (gameTrackingObj != nil) {
        
        //we dont want 0 as the challenge id
        NSNumber *challengeId = [NSNumber numberWithInt:(arc4random() % 10000 + 1)];
        
        [[GameTrackingEngine sharedClient]
            sendGameTrackingInfo:gameTrackingObj
            challengeId:challengeId
            onSuccess:^(){
                [self sendScoreChallengeToPlayers:players score:score context:challengeId.integerValue message:message];
            } onFailure:^(NSError *error){
                [self sendScoreChallengeToPlayers:players score:score context:0 message:message];
            }];
    } else {
        [self sendScoreChallengeToPlayers:players score:score context:0 message:message];
    }
}

- (void) sendScoreChallengeToPlayers:(NSArray*)players
                             score:(uint64_t) score
                             context:(uint64_t) context
                             message:(NSString*) message {
    
    GKScore *gkScore =
        [[GKScore alloc]
         initWithCategory:
         kHighScoreLeaderboardCategory];

    gkScore.context = context;
    gkScore.value = score;
    [gkScore issueChallengeToPlayers:players message:message];
}

// This method is used to load the challenges
// that have been issued to the local player
-(void) loadChallenges {
    if (_gameCenterFeaturesEnabled == NO) {
        return;
    }
    [GKChallenge
     loadReceivedChallengesWithCompletionHandler:^(NSArray *challenges, NSError *error) {
         [self setLastError:error];
         
         BOOL success = (error == nil);
         if (success && [_delegate respondsToSelector:@selector(onChallengesReceived:)]) {
             [_delegate onChallengesReceived:challenges];
         }
    }];
}
@end
