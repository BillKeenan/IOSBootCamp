//
//  GhostMonkey.m
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "GhostMonkey.h"


@implementation GhostMonkey
- (void) changeState:(MonkeyState) newState {

    [super changeState:newState];
    
    if(newState == kDead) {
        [self stopAllActions];
        [self setDisplayFrame:
                [[CCSpriteFrameCache
                sharedSpriteFrameCache]
                    spriteFrameByName:
                    @"monkey_ghost_dead.png"]];
    }
}
@end
