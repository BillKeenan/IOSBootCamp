//
//  HudLayer.h
//  MonkeyJump
//
//  Created by Kauserali on 27/07/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

@interface HudLayer : CCLayer
- (void) updateDistanceLabel:(int) distance;
- (void) updateLivesLabel:(int) lives;
@end
