//
//  GameTrackingObj.h
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//
//

@interface GameTrackingObj : NSObject<NSCopying>
@property (nonatomic, strong) NSMutableArray *jumpTimingSinceStartOfGame;
@property (nonatomic, strong) NSMutableArray *hitTimingSinceStartOfGame;
@property (nonatomic, readwrite) long seed;

- (void) addJumpTime:(double) jumpTime;
- (void) addHitTime:(double) hitTime;
@end
