//
//  GameTrackingEngine.m
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//
//

#import "GameTrackingEngine.h"
#import "GameTrackingObj.h"
#import "AFJSONRequestOperation.h"

#define kSeekKey @"Seed"
#define kJumpArrayKey @"JumpArray"
#define kHitArrayKey @"HitArray"

@implementation GameTrackingEngine

+ (GameTrackingEngine *)sharedClient {
    
    static GameTrackingEngine *sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedClient = [[GameTrackingEngine alloc] initWithBaseURL:[NSURL URLWithString:BASE_URL]];
    });
    
    return sharedClient;
}

- (id) initWithBaseURL:(NSURL *)url {
    self = [super initWithBaseURL:url];
    if (self) {
        self.parameterEncoding = AFJSONParameterEncoding;
        [self registerHTTPOperationClass:[AFJSONRequestOperation class]];
        
        [self setDefaultHeader:@"Accept" value:@"application/json"];
    }
    return self;
}

- (void) retrieveGameTrackingDetailsForKey:(int64_t) key
         onSuccess:(GameTrackingObjResponce) responceBlock
         onFailure:(GameTrackingObjError) errorBlock {
    
    NSDictionary *params = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:key] forKey:@"challengeId"];
    [self getPath:@"ChallengesAPI.php"
          parameters:params
          success:^(AFHTTPRequestOperation *operation, id responceObject) {
              
              if (responceBlock != nil &&
                  responceObject != nil &&
                  [responceObject isKindOfClass:[NSDictionary class]]) {
                  
                  GameTrackingObj *gameTrackingObj = [[GameTrackingObj alloc] init];
                  gameTrackingObj.jumpTimingSinceStartOfGame = [responceObject objectForKey:kJumpArrayKey];
                  gameTrackingObj.hitTimingSinceStartOfGame = [responceObject objectForKey:kHitArrayKey];
                  gameTrackingObj.seed = [[responceObject objectForKey:kSeekKey] intValue];
                  
                  responceBlock(gameTrackingObj);
              }
          } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
              if (errorBlock != nil) {
                  errorBlock(error);
              }
          }];
}

- (void) sendGameTrackingInfo:(GameTrackingObj*) gameTrackingObj
                    challengeId:(NSNumber*) challengeId
                    onSuccess:(GameTrackingObjSentSuccessfully) successBlock
                    onFailure:(GameTrackingObjError) errorBlock {
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            [NSNumber numberWithInt:gameTrackingObj.seed], kSeekKey,
                            gameTrackingObj.jumpTimingSinceStartOfGame, kJumpArrayKey,
                            gameTrackingObj.hitTimingSinceStartOfGame, kHitArrayKey, nil];
    
    NSString *postPath = [NSString stringWithFormat:@"ChallengesAPI.php?challengeId=%d", challengeId.intValue];
    [self postPath:postPath
          parameters:params
          success:^(AFHTTPRequestOperation *operation, id responceObject){
              if (successBlock != nil) {
                  successBlock();
              }
          } failure:^(AFHTTPRequestOperation *operation, NSError *error){
              if (errorBlock != nil) {
                  errorBlock(error);
              }
          }];
}
@end
