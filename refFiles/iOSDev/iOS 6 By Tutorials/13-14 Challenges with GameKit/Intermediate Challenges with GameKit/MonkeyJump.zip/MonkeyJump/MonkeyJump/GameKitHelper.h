//
//  GameKitHelper.h
//  MonkeyJump
//
//  Created by Kauserali on 02/08/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <GameKit/GameKit.h>

@class GameTrackingObj;
@protocol GameKitHelperProtocol<NSObject>

@optional
-(void) onScoresSubmitted:(bool)success;

-(void) onAchievementReported:(GKAchievement*)achievement;
-(void) onAchievementsLoaded:(NSDictionary*)achievements;
-(void) onResetAchievements:(bool)success;

-(void) onScoresOfFriendsToChallengeListReceived:
            (NSArray*) scores;
-(void) onPlayerInfoReceived:
            (NSArray*)players;
-(void) onChallengesReceived:
            (NSArray*)challenges;
@end


@interface GameKitHelper : NSObject

@property (nonatomic, assign) id<GameKitHelperProtocol> delegate;
@property (nonatomic, readonly) NSError* lastError;
@property (nonatomic, readonly) NSMutableDictionary* achievements;
@property (nonatomic, readwrite)
        BOOL includeLocalPlayerScore;

+ (id) sharedGameKitHelper;

// Player authentication, info
-(void) authenticateLocalPlayer;

// Scores
-(void) submitScore:(int64_t)score
           category:(NSString*)category;

// Achievements
-(void) reportAchievementWithID:
        (NSString*)identifier
                percentComplete:(float)percent;
-(void) resetAchievements;

// Game center UI
-(void) showGameCenterViewController;

// Share score through code
-(void) shareScore:
        (int64_t)score
         catergory:(NSString*)category;

// Method to show friends picker
-(void)
    showFriendsPickerViewControllerForScore:
    (int64_t)score gameTrackObj:(GameTrackingObj*) gameTrackObj;

// Method to show the challenge picker
-(void) showChallengePickerViewController;

// Method used to find friends who are playing a similar game and their scores
-(void) findScoresOfFriendsToChallenge;

-(void) getPlayerInfo:(NSArray*)playerList;

-(void) sendScoreChallengeToPlayers:
        (NSArray*)players
        withScore:(int64_t)score
        message:(NSString*)message;

-(void) sendScoreChallengeToPlayers:
        (NSArray *)players
        withScore:(int64_t)score
        message:(NSString *)message
        withGameTrackingObj:(GameTrackingObj*)gameTrackingObj;

-(void) loadChallenges;
@end
