//
//  GhostMonkey.h
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Monkey.h"

@interface GhostMonkey : Monkey

@end
