//
//  GameScene.h
//  MonkeyJump
//
//  Created by Kauserali on 26/07/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

@class GameTrackingObj;

@interface GameScene : CCScene
- (id) initWithGameTrackingObj:(GameTrackingObj*) gameTrackingObj;
@end
