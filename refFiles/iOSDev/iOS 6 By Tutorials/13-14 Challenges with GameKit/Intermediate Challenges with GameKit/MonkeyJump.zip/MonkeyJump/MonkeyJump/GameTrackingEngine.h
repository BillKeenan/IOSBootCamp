//
//  GameTrackingEngine.h
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//
//

#import "AFHTTPClient.h"

@class GameTrackingObj;

typedef void (^GameTrackingObjResponce)(GameTrackingObj *gameTrackingObj);
typedef void (^GameTrackingObjSentSuccessfully)();
typedef void (^GameTrackingObjError)(NSError *error);

@interface GameTrackingEngine : AFHTTPClient

+ (GameTrackingEngine *)sharedClient;

- (void) retrieveGameTrackingDetailsForKey:(int64_t) key
        onSuccess:(GameTrackingObjResponce) responceBlock
        onFailure:(GameTrackingObjError) errorBlock;

- (void) sendGameTrackingInfo:(GameTrackingObj*) gameTrackingObj
        challengeId:(NSNumber*) challengeId
        onSuccess:(GameTrackingObjSentSuccessfully) successBlock
        onFailure:(GameTrackingObjError) errorBlock;
@end
