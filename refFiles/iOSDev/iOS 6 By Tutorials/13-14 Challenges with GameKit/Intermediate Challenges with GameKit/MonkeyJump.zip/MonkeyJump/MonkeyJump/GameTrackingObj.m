//
//  GameTrackingObj.m
//  MonkeyJump
//
//  Created by Kauserali on 20/08/12.
//
//

#import "GameTrackingObj.h"

@implementation GameTrackingObj

- (id) init {
    self = [super init];
    if (self) {
        self.seed = 1;
    }
    return self;
}

- (void) addJumpTime:(double) jumpTime {
    if (self.jumpTimingSinceStartOfGame == nil) {
        self.jumpTimingSinceStartOfGame = [NSMutableArray array];
    }
    [self.jumpTimingSinceStartOfGame addObject:[NSNumber numberWithDouble:jumpTime]];
}

- (void) addHitTime:(double) hitTime {
    if (self.hitTimingSinceStartOfGame == nil) {
        self.hitTimingSinceStartOfGame = [NSMutableArray array];
    }
    [self.hitTimingSinceStartOfGame addObject:[NSNumber numberWithDouble:hitTime]];
}

- (id)copyWithZone:(NSZone *)zone {
    GameTrackingObj *copy = [[GameTrackingObj allocWithZone:zone] init];
    copy.jumpTimingSinceStartOfGame = [self.jumpTimingSinceStartOfGame mutableCopy];
    copy.hitTimingSinceStartOfGame = [self.hitTimingSinceStartOfGame mutableCopy];
    copy.seed = self.seed;
    return copy;
}

- (NSString*) description {
    return [NSString stringWithFormat:@"Jump times: %@, Hit times: %@, seed: %ld", self.jumpTimingSinceStartOfGame.description, self.hitTimingSinceStartOfGame.description, self.seed];
}
@end
