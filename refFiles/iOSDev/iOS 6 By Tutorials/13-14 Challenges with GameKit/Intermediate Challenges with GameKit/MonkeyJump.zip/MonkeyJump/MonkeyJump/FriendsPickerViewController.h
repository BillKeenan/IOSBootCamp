//
//  FriendsPickerViewController.h
//  MonkeyJump
//
//  Created by Kauserali on 03/08/12.
//
//

@class GameTrackingObj;

typedef void
        (^FriendsPickerCancelButtonPressed)();
typedef void
        (^FriendsPickerChallengeButtonPressed)();

@interface FriendsPickerViewController : UIViewController
@property (nonatomic, copy)
    FriendsPickerCancelButtonPressed
    cancelButtonPressedBlock;
@property (nonatomic, copy)
    FriendsPickerChallengeButtonPressed
    challengeButtonPressedBlock;

- (id)initWithScore:(int64_t) score gameTrackObj:(GameTrackingObj*) gameTrackObj;
@end
