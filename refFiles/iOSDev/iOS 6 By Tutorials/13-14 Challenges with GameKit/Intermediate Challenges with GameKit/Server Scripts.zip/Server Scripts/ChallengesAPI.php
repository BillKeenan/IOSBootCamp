<?PHP
    $request_method = 
            strtolower($_SERVER['REQUEST_METHOD']);
    
    # This method is used to get the
    # game details for a specific Challenge
    # Storage used is MySql
    
    function GetData($challengeId){
        # 1: Create a connection to the databse
        
        $link = mysql_connect('localhost','root','') 
                or die('Cannot connect to the DB');
        
        # 2: Select the database
        
        mysql_select_db('challenges',$link) 
                or die('Cannot select the DB');
        
        # 3: Run the query
        
        $query = "SELECT * from ChallengesInfo WHERE ChallengeId = '".$challengeId ."'";
        $result = mysql_query($query,$link)
                    or die('Errant query:  '.$query);
        
        $data = '';
        if(mysql_num_rows($result)) {
            while($info = mysql_fetch_array( $result )) {
                $data = $info['JSON'];
            }
        }
        @mysql_close($link);
        
        # 4: Return the results
        return $data;
    }
    
    # Check if the challenge id is set
    
    if(isset($_GET['challengeId']) ) { 
        
        # Retrieve the challengeId from the url
        $challengeId = $_GET['challengeId'];

        // In case of "GET" call
        if($request_method == 'get'){
            $data = GetData($challengeId);
            
            if($data == ''){
                header("HTTP/1.0 404 Not Found");
            } else{
                header('Content-type: text/json');
                echo $data;
            }
        } else {
            
            $data = file_get_contents('php://input');
            if($data != ''){
                $existingData = GetData($challengeId);
                $link =
                    mysql_connect('localhost','root','')
                        or die('Cannot connect to the DB');
                
                mysql_select_db('challenges',$link)
                        or die('Cannot select the DB');

                if($existingData == ''){
                    $query ="INSERT INTO ChallengesInfo values ('".$challengeId."','".$data."')";
                    $message = "Data Inserted";
                } else {
                    $query ="UPDATE ChallengesInfo set JSON = '".$data."' where ChallengeId = '".$challengeId ."'";
                    $message = "Data updated";
                }
                
                mysql_query($query,$link)
                       or die('Errant query:  '.$query);
                header('Content-type: text/json');
                echo '{"__message" : "'.$message.'"}';
            }    
        }
        
    } else {
        header('STATUS 400');
        header('Content-type: text/json');
        echo '{"__message" : "Please provide a challenge id"}';
    }
?>