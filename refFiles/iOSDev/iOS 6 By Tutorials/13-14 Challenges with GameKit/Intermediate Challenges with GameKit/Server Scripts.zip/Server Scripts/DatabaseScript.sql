# Remove the challenges database
drop database if exists challenges;

# Create a fresh challenges database
create database challenges;

# Use the new challenges database
use challenges;

# Remove the challengesInfo Table
drop table if exists ChallengesInfo;

# Create a fresh table
CREATE TABLE `ChallengesInfo` (
  `ChallengeId` varchar(255) NOT NULL,
  `JSON` text,
  PRIMARY KEY (`ChallengeId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;