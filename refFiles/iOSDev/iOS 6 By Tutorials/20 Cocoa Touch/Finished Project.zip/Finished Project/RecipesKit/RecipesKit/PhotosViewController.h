//
//  PhotosViewController.h
//  RecipesKit
//
//  Created by Felipe on 8/10/12.
//  Copyright (c) 2012 Felipe Last Marsetti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotosViewController : UIViewController

@property (strong, nonatomic) UIImage *image;
@property (assign, nonatomic) NSUInteger index;

@end
