//
//  ServingsViewController.h
//  RecipesKit
//
//  Created by Felipe on 8/10/12.
//  Copyright (c) 2012 Felipe Last Marsetti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServingsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

@end
