//
//  RecipeCell.h
//  RecipesKit
//
//  Created by Felipe on 7/2/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define RecipeCellReuseIdentifier   @"RecipeCellNib"

@interface RecipeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *detailTextLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
