//
//  RecipeCodeCell.h
//  RecipesKit
//
//  Created by Felipe on 7/2/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define RecipeCodeCellReuseIdentifier   @"RecipeCodeCell"
#define RecipeCodeCellSegue             @"RecipeCodeCellSegue"

@interface RecipeCodeCell : UITableViewCell

@property (strong, nonatomic) UILabel *nameLabel;
@property (strong, nonatomic) UILabel *servingsLabel;

@end
