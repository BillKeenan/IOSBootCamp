//
//  ServingsViewController.m
//  RecipesKit
//
//  Created by Felipe on 8/10/12.
//  Copyright (c) 2012 Felipe Last Marsetti. All rights reserved.
//

#import "ServingsViewController.h"

@interface ServingsViewController () <UIPickerViewDataSource, UIPickerViewDelegate>

@end

@implementation ServingsViewController

#pragma mark - Picker Data Source

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
   return 10;
}

#pragma mark - Picker Delegate

- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", row + 1]];
}

#pragma mark - View Lifecycle

- (void)didReceiveMemoryWarning
{
    if ([self.view window] == nil)
    {
        _pickerView = nil;
        self.view = nil;
    }
    
    [super didReceiveMemoryWarning];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

@end
