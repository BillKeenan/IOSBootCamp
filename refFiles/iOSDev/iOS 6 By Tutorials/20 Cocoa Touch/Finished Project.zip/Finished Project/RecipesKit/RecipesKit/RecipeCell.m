//
//  RecipeCell.m
//  RecipesKit
//
//  Created by Felipe on 7/2/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import "RecipeCell.h"

@implementation RecipeCell

@end
