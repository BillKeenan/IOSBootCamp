
@interface RankingsViewController : UIViewController

@property (nonatomic, strong) NSMutableArray *players;

@end
