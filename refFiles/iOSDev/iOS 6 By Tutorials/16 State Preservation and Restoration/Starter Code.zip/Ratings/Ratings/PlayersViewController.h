
@interface PlayersViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *players;

@end
