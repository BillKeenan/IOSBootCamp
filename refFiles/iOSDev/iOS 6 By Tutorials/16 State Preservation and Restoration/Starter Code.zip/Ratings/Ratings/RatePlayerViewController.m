
#import "RatePlayerViewController.h"
#import "Player.h"

@implementation RatePlayerViewController

- (void)viewDidLoad
{
	[super viewDidLoad];
	self.title = self.player.name;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)rateAction:(UIButton *)sender
{
	self.player.rating = sender.tag;
	[self.delegate ratePlayerViewController:self didPickRatingForPlayer:self.player];
}

@end
