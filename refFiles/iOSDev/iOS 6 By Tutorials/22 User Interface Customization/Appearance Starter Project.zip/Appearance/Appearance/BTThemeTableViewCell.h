//
//  BTThemeTableViewCell.h
//  AppearanceChapter
//
//  Created by Adam Burkepile on 7/21/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTThemeTableViewCell : UITableViewCell

@end
