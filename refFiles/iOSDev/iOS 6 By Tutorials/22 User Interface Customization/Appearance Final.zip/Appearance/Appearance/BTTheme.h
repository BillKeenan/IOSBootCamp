//
//  BTTheme.h
//  Appearance
//
//  Created by Fahim Farook on 14/8/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

@protocol BTTheme

- (UIColor*)backgroundColor;
- (UIImage*)imageForNavigationBar;
- (UIImage*)imageForNavigationBarLandscape;
- (NSDictionary*)navBarTextDictionary;
- (UIImage*)imageForNavigationBarShadow;
- (UIImage*)imageForBarButtonNormal;
- (UIImage*)imageForBarButtonHighlighted;
- (UIImage*)imageForBarButtonNormalLandscape;
- (UIImage*)imageForBarButtonHighlightedLandscape;
- (UIImage*)imageForBarButtonDoneNormal;
- (UIImage*)imageForBarButtonDoneHighlighted;
- (UIImage*)imageForBarButtonDoneNormalLandscape;
- (UIImage*)imageForBarButtonDoneHighlightedLandscape;
- (NSDictionary*)barButtonTextDictionary;
- (UIColor*)pageTintColor;
- (UIColor*)pageCurrentTintColor;
- (UIImage*)imageForStepperUnselected;
- (UIImage*)imageForStepperSelected;
- (UIImage*)imageForStepperDecrement;
- (UIImage*)imageForStepperIncrement;
- (UIImage*)imageForStepperDividerUnselected;
- (UIImage*)imageForStepperDividerSelected;
- (UIColor*)switchOnTintColor;
- (UIColor*)switchThumbTintColor;
- (UIImage*)imageForSwitchOn;
- (UIImage*)imageForSwitchOff;
- (UIColor*)progressBarTintColor;
- (UIColor*)progressBarTrackTintColor;
- (NSDictionary*)labelTextDictionary;
- (NSDictionary*)buttonTextDictionary;
- (UIImage*)imageForButtonNormal;
- (UIImage*)imageForButtonHighlighted;
- (UIColor*)upperGradient;
- (UIColor*)lowerGradient;
- (UIColor*)seperatorColor;
- (Class)gradientLayer;
- (NSDictionary*)tableViewCellTextDictionary;

@end

@interface BTThemeManager : NSObject
+ (id<BTTheme>)sharedTheme;
+ (void)setSharedTheme:(id<BTTheme>)inTheme;
+ (void)applyTheme;
+ (void)customizeView:(UIView *)view;
+ (void)customizeNavigationBar:(UINavigationBar *)navigationBar;
+ (void)customizeButton:(UIButton*)button;
+ (void)customizeTableViewCell:(UITableViewCell*)tableViewCell;
@end
