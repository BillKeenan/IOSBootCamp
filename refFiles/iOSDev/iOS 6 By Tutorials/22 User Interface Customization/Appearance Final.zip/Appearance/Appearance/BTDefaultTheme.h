//
//  BTDefaultTheme.h
//  Appearance
//
//  Created by Fahim Farook on 14/8/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "BTTheme.h"

@interface BTGradientLayer : CAGradientLayer
@end

@interface BTDefaultTheme : NSObject<BTTheme>

@end
