//
//  BTTheme.m
//  Appearance
//
//  Created by Fahim Farook on 14/8/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "BTTheme.h"
#import "BTDefaultTheme.h"

@implementation BTThemeManager

static id<BTTheme> _theme = nil;

+ (id<BTTheme>)sharedTheme {
    return _theme;
}

+ (void)setSharedTheme:(id<BTTheme>)inTheme {
    _theme = inTheme;
    [self applyTheme];
}

+ (void)applyTheme {
    id<BTTheme> theme = [self sharedTheme];
	
	// Navigation bar
	UINavigationBar* NavBarAppearence = [UINavigationBar
										 appearance];
	[NavBarAppearence setBackgroundImage:[theme
										  imageForNavigationBar]
						   forBarMetrics:UIBarMetricsDefault];
	[NavBarAppearence setBackgroundImage:[theme
										  imageForNavigationBarLandscape]
						   forBarMetrics:UIBarMetricsLandscapePhone];
	[NavBarAppearence setTitleTextAttributes:[theme
											  navBarTextDictionary]];
	[[NSNotificationCenter defaultCenter]
	 postNotification:[NSNotification
					   notificationWithName:kThemeChange
					   object:nil]];
	[NavBarAppearence setShadowImage:[theme
									  imageForNavigationBarShadow]];
	// Bar button item
	UIBarButtonItem* barButton = [UIBarButtonItem appearance];
	
	[barButton setBackgroundImage:[theme imageForBarButtonNormal]
						 forState:UIControlStateNormal
					   barMetrics:UIBarMetricsDefault];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonHighlighted]
						 forState:UIControlStateHighlighted
					   barMetrics:UIBarMetricsDefault];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonNormalLandscape]
						 forState:UIControlStateNormal
					   barMetrics:UIBarMetricsLandscapePhone];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonHighlightedLandscape]
						 forState:UIControlStateHighlighted
					   barMetrics:UIBarMetricsLandscapePhone];
	
	[barButton setBackgroundImage:[theme
								   imageForBarButtonDoneNormal]
						 forState:UIControlStateNormal
							style:UIBarButtonItemStyleDone
					   barMetrics:UIBarMetricsDefault];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonDoneHighlighted]
						 forState:UIControlStateHighlighted
							style:UIBarButtonItemStyleDone
					   barMetrics:UIBarMetricsDefault];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonDoneNormalLandscape]
						 forState:UIControlStateNormal
							style:UIBarButtonItemStyleDone
					   barMetrics:UIBarMetricsLandscapePhone];
	[barButton setBackgroundImage:[theme
								   imageForBarButtonDoneHighlightedLandscape]
						 forState:UIControlStateHighlighted
							style:UIBarButtonItemStyleDone
					   barMetrics:UIBarMetricsLandscapePhone];
	[barButton setTitleTextAttributes:[theme
									   barButtonTextDictionary]
							 forState:UIControlStateNormal];
	
	[barButton setTitleTextAttributes:[theme
									   barButtonTextDictionary]
							 forState:UIControlStateNormal];
	// Page control
	UIPageControl* pageAppearence = [UIPageControl appearance];
	[pageAppearence setCurrentPageIndicatorTintColor:
	 [theme pageCurrentTintColor]];
	[pageAppearence setPageIndicatorTintColor:
	 [theme pageTintColor]];
	// Stepper
	UIStepper* stepperAppearence = [UIStepper appearance];
	[stepperAppearence setBackgroundImage:
	 [theme imageForStepperUnselected]
								 forState:UIControlStateNormal];
	[stepperAppearence setBackgroundImage:
	 [theme imageForStepperSelected]
								 forState:UIControlStateHighlighted];
	[stepperAppearence setDividerImage:
	 [theme imageForStepperDividerUnselected]
				   forLeftSegmentState:UIControlStateNormal
					 rightSegmentState:UIControlStateNormal];
	[stepperAppearence setDividerImage:
	 [theme imageForStepperDividerSelected]
				   forLeftSegmentState:UIControlStateSelected
					 rightSegmentState:UIControlStateNormal];
	[stepperAppearence setDividerImage:
	 [theme imageForStepperDividerSelected]
				   forLeftSegmentState:UIControlStateNormal
					 rightSegmentState:UIControlStateSelected];
	[stepperAppearence setDividerImage:
	 [theme imageForStepperDividerSelected]
				   forLeftSegmentState:UIControlStateSelected
					 rightSegmentState:UIControlStateSelected];
	[stepperAppearence setIncrementImage:
	 [theme imageForStepperIncrement]
								forState:UIControlStateNormal];
	[stepperAppearence setDecrementImage:
	 [theme imageForStepperDecrement]
								forState:UIControlStateNormal];
	// Switch control
	UISwitch* switchAppearence = [UISwitch appearance];
	[switchAppearence setTintColor:[theme switchThumbTintColor]];
	[switchAppearence setOnTintColor:[theme switchOnTintColor]];
	[switchAppearence setOnImage:[theme imageForSwitchOn]];
	[switchAppearence setOffImage:[theme imageForSwitchOff]];
	// Progress bar
	UIProgressView* progressAppearence = [UIProgressView appearance];
    [progressAppearence setProgressTintColor:[theme progressBarTintColor]];
    [progressAppearence setTrackTintColor:[theme progressBarTrackTintColor]];
	// Label
//	UILabel* labelAppearence = [UILabel appearance];
//	[labelAppearence setTextColor:
//	 [theme labelTextDictionary][UITextAttributeTextColor]];
//	[labelAppearence setFont:
//	 [theme labelTextDictionary][UITextAttributeFont]];

}

+ (void)customizeView:(UIView *)view
{
    id <BTTheme> theme = [self sharedTheme];
    UIColor *backgroundColor = [theme backgroundColor];
    [view setBackgroundColor:backgroundColor];
}

+ (void)customizeNavigationBar:(UINavigationBar *)navigationBar {
    id <BTTheme> theme = [self sharedTheme];
    [navigationBar setBackgroundImage:[theme
									   imageForNavigationBar]
						forBarMetrics:UIBarMetricsDefault];
    [navigationBar setBackgroundImage:[theme
									   imageForNavigationBarLandscape]
						forBarMetrics:UIBarMetricsLandscapePhone];
    [navigationBar setTitleTextAttributes:[theme
										   navBarTextDictionary]];
	[navigationBar setShadowImage:[theme
								   imageForNavigationBarShadow]];
}

+ (void)customizeButton:(UIButton*)button {
    id <BTTheme> theme = [self sharedTheme];
    
    [button setTitleColor:
     [theme buttonTextDictionary][UITextAttributeTextColor]
				 forState:UIControlStateNormal];
    [[button titleLabel] setFont:
     [theme buttonTextDictionary][UITextAttributeFont]];
    [button setBackgroundImage:
     [theme imageForButtonNormal]?
     [theme imageForButtonNormal] : nil
                      forState:UIControlStateNormal];
    [button setBackgroundImage:
     [theme imageForButtonHighlighted]?
     [theme imageForButtonHighlighted]:nil
                      forState:UIControlStateHighlighted];
}

+ (void)customizeTableViewCell:(UITableViewCell*)tableViewCell {
    id <BTTheme> theme = [self sharedTheme];
    
    [[tableViewCell textLabel] setTextColor:
	 [theme tableViewCellTextDictionary][UITextAttributeTextColor]];
    [[tableViewCell textLabel] setFont:
	 [theme tableViewCellTextDictionary][UITextAttributeFont]];
}

@end
