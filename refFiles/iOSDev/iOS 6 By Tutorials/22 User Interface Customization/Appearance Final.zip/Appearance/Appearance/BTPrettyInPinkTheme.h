//
//  BTPrettyInPinkTheme.h
//  Appearance
//
//  Created by Fahim Farook on 14/8/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "BTDefaultTheme.h"

@interface BTPrettyInPinkTheme : BTDefaultTheme

@end
