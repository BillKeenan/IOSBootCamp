//
//  ConfereceRemindersViewController.h
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 03/07/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

@interface ConfereceRemindersViewController : UITableViewController

@end
