//
//  ConfereceRemindersViewController.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 03/07/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "ConfereceRemindersViewController.h"
#import "EventKitController.h"

@interface ConfereceRemindersViewController () {
    EventKitController *_eventKitController;
}
@end

@implementation ConfereceRemindersViewController

- (void) viewDidLoad {
    [super viewDidLoad];
    
    _eventKitController = [[EventKitController alloc] init];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(remindersPermissionGranted)
     name:RemindersAccessGranted
     object:_eventKitController];
}

- (void) dealloc {
    [_eventKitController
     stopBroadcastingModelChangedNotifications];
    
    [[NSNotificationCenter defaultCenter]
     removeObserver:self];
}

- (void) remindersPermissionGranted {
    [_eventKitController
     startBroadcastingModelChangedNotifications];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(refreshView)
     name:RemindersModelChangedNotification
     object:_eventKitController];
    
    [_eventKitController fetchAllConferenceReminders];
}

- (void) refreshView {
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView
  numberOfRowsInSection:(NSInteger)section {
    return _eventKitController.reminders.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView
          cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell =
    [tableView
     dequeueReusableCellWithIdentifier:
     @"ReminderCells"];
    
    EKReminder *reminder =
    (EKReminder*)_eventKitController.
    reminders[indexPath.row];
    
    cell.textLabel.text = reminder.title;
    if (reminder.completed) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark - Table view delegate

- (void)tableView: (UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell =
    [tableView cellForRowAtIndexPath:indexPath];
    
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        [_eventKitController reminder:
         _eventKitController.reminders[indexPath.row]
                  setCompletionFlagTo:NO];
    } else {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [_eventKitController reminder:
         _eventKitController.reminders[indexPath.row]
                  setCompletionFlagTo:YES];
    }
}

@end
