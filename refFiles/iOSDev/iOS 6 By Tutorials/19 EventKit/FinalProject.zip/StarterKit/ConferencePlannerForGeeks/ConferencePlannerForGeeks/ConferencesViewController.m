//
//  ConferencesViewController.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 27/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "ConferencesViewController.h"
#import "ConferenceDetailViewController.h"
#import "ConferenceCell.h"
#import "Conference.h"

@implementation ConferencesViewController

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"ConferenceDetails"]) {
        ConferenceDetailViewController *detailViewController = (ConferenceDetailViewController*) [segue destinationViewController];
        detailViewController.conference = self.conferences[self.tableView.indexPathForSelectedRow.row];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.conferences count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    ConferenceCell *cell = (ConferenceCell*) [tableView dequeueReusableCellWithIdentifier:@"ConferenceCell"];
    Conference *conference = self.conferences[indexPath.row];
    cell.nameLabel.text = conference.name;
    cell.imageView.image = [UIImage imageNamed:conference.imageName];
    return cell;
}
@end
