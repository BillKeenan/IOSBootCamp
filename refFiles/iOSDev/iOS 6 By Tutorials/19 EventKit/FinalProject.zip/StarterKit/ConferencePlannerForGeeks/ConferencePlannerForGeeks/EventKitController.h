//
//  EventKitController.h
//  ConferencePlannerForGeeks
//
//  Created by Ray Wenderlich on 7/24/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>

extern NSString *const RemindersModelChangedNotification;
extern NSString *const EventsAccessGranted;
extern NSString *const RemindersAccessGranted;

@interface EventKitController : NSObject

@property (strong, readonly) EKEventStore *eventStore;
@property (assign, readonly) BOOL eventAccess;
@property (assign, readonly) BOOL reminderAccess;
@property (strong) NSMutableArray *reminders;

-(void)addEventWithName:(NSString*)eventName startTime:(NSDate*)startDate endTime:(NSDate*)endDate;
-(void)addRecurringEventWithName:(NSString*)eventName startTime:(NSDate*)startDate endTime:(NSDate*)endDate;
-(void)deleteEventWithName:(NSString*)eventName startTime:(NSDate*)startDate endTime:(NSDate*)endDate;
-(void)addReminderWithTitle:(NSString*)title dueTime:(NSDate*)dueDate;
-(void)fetchAllConferenceReminders;
-(void)startBroadcastingModelChangedNotifications;
-(void)stopBroadcastingModelChangedNotifications;
-(void)reminder:(EKReminder*)reminder setCompletionFlagTo:(BOOL)flag;

@end
