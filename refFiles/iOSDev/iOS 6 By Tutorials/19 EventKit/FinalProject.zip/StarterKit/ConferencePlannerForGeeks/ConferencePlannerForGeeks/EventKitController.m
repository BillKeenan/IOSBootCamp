//
//  EventKitController.m
//  ConferencePlannerForGeeks
//
//  Created by Ray Wenderlich on 7/24/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "EventKitController.h"
#define kRemindersCalendarTitle @"Conference reminders"

@interface EventKitController() {
    dispatch_queue_t _fetchQueue;
}
@end

NSString *const RemindersModelChangedNotification = @"RemindersModelChangedNotification";
NSString *const EventsAccessGranted = @"EventsAccessGranted";
NSString *const RemindersAccessGranted = @"RemindersAccessGranted";

@implementation EventKitController

- (id) init {
    self = [super init];
    if (self) {
        _eventStore = [[EKEventStore alloc] init];
        
        [_eventStore
            requestAccessToEntityType:EKEntityTypeEvent
            completion:^(BOOL granted, NSError *error) {
                
            if (granted) {
                _eventAccess = YES;
                [[NSNotificationCenter defaultCenter]
                 postNotificationName:
                 EventsAccessGranted
                 object:self];
            } else {
                NSLog(@"Event access not granted: %@",
                                            error);
            }
        }];
        [_eventStore
            requestAccessToEntityType:EKEntityTypeReminder
            completion:^(BOOL granted, NSError *error) {
                
            if (granted) {
                _reminderAccess = YES;
                _eventAccess = YES;
                [[NSNotificationCenter defaultCenter]
                 postNotificationName:
                 RemindersAccessGranted
                 object:self];
            } else {
                NSLog(@"Reminder access not granted: %@", error);
            }
        }];
        _fetchQueue =
            dispatch_queue_create("com.conferencePlannerForGeeks.fetchQueue",
                                  DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

- (void) addEventWithName:(NSString*) eventName
                startTime:(NSDate*) startDate
                  endTime:(NSDate*) endDate {
    
    if (!_eventAccess) {
        NSLog(@"No event acccess!");
        return;
    }
    
    //1. Create an Event
    EKEvent *event = [EKEvent
                      eventWithEventStore:self.eventStore];
    
    //2. Set the title
    event.title = eventName;
    
    //3. Set the start and end date
    event.startDate = startDate;
    event.endDate = endDate;
    
    //4. Set an alarm (This is optional)
    EKAlarm *alarm = [EKAlarm alarmWithRelativeOffset:-1800];
    [event addAlarm:alarm];
    
    //5. Add a note (This is optional)
    event.notes = @"This will be exciting";
    
    //6. Specify the calendar to store the event
    event.calendar=self.eventStore.defaultCalendarForNewEvents;
    
    NSError *err;
    BOOL success = [self.eventStore
                    saveEvent:event
                    span:EKSpanThisEvent
                    commit:YES error:&err];
    
    if (!success) {
        NSLog(@"There was an error saving event: %@", err);
    }
}

- (void) addRecurringEventWithName:(NSString*) eventName
                         startTime:(NSDate*) startDate
                           endTime:(NSDate*) endDate {
    
    if (!_eventAccess) {
        NSLog(@"No event acccess!");
        return;
    }
    
    //1. Create an Event
    EKEvent *event = [EKEvent
                      eventWithEventStore:self.eventStore];
    
    //2. Set the title
    event.title = eventName;
    
    //3. Set the start and end date
    event.startDate = startDate;
    event.endDate = endDate;
    
    //4. Set an alarm (This is optional)
    EKAlarm *alarm = [EKAlarm
                      alarmWithRelativeOffset:-1800];
    [event addAlarm:alarm];
    
    //5. Add a note (This is optional)
    event.notes = @"This will be exciting";
    
    //6. Add the recurrrence rule.
    EKRecurrenceRule *rule =
    [[EKRecurrenceRule alloc]
     initRecurrenceWithFrequency:
     EKRecurrenceFrequencyYearly
     interval:1 end:nil];
    event.recurrenceRules = @[rule];
    
    //7. Specify the calendar to store the event to
    event.calendar =
    self.eventStore.defaultCalendarForNewEvents;
    
    NSError *err;
    BOOL success  = [self.eventStore
                     saveEvent:event span:EKSpanThisEvent
                     commit:YES error:&err];
    
    if (!success) {
        NSLog(@"There was an error saving event: %@", err);
    }
}

- (void) deleteEventWithName:(NSString*) eventName
                   startTime:(NSDate*) startDate
                     endTime:(NSDate*) endDate {
    
    if (!_eventAccess) {
        NSLog(@"No event acccess!");
        return;
    }
    
    dispatch_async(_fetchQueue, ^{
        
        //1. Create a prediate to find the EKEvent to delete
        NSPredicate *predicate =
        [self.eventStore
         predicateForEventsWithStartDate:startDate
         endDate:endDate
         calendars:
         @[self.eventStore.defaultCalendarForNewEvents]];
        
        NSArray *events =
        [self.eventStore eventsMatchingPredicate:predicate];
        
        //2. Post filter the events array
        NSPredicate *titlePredicate =
        [NSPredicate
         predicateWithFormat:@"title matches %@",
         eventName];
        events = [events
                  filteredArrayUsingPredicate:titlePredicate];
        
        //3. Delete each of these events
        NSError *err;
        for (EKEvent *event in events) {
            [self.eventStore
             removeEvent:event
             span:event.hasRecurrenceRules ?
             EKSpanFutureEvents:EKSpanThisEvent
             commit:NO error:&err];
        }
        
        BOOL success = [self.eventStore commit:&err];
        if (!success) {
            NSLog(@"There was an error deleting event");
        }
    });
    if (!_eventAccess) {
        NSLog(@"No event acccess!");
        return;
    }
}

- (void) addReminderWithTitle:(NSString*) title
                      dueTime:(NSDate*) dueDate {
    
    if (!_reminderAccess) {
        NSLog(@"No reminder acccess!");
        return;
    }
    
    //1.Create a reminder
    EKReminder *reminder =
    [EKReminder
     reminderWithEventStore:
     self.eventStore];
    
    //2. Set the title
    reminder.title = title;
    
    //3. Set the calendar
    reminder.calendar =
    [self calendarForReminders];
    
    //4. Extract the NSDateComponents from the dueDate
    NSCalendar *calendar =
    [NSCalendar currentCalendar];
    
    NSUInteger unitFlags =
    NSEraCalendarUnit |
    NSYearCalendarUnit |
    NSMonthCalendarUnit |
    NSDayCalendarUnit;
    
    NSDateComponents *dueDateComponents =
    [calendar components:unitFlags
                fromDate:dueDate];
    
    //5. Set the due date
    reminder.dueDateComponents = dueDateComponents;
    
    //6. Save the reminder
    NSError *err;
    BOOL success = [self.eventStore
                    saveReminder:reminder
                    commit:YES error:&err];
    if (!success) {
        NSLog(@"There was an error saving the reminder %@",
              err);
    }
}
- (EKCalendar*) calendarForReminders {
    
    //1
    for (EKCalendar *calendar in
         [self.eventStore
          calendarsForEntityType:EKEntityTypeReminder]) {
             
             if ([calendar.title
                  isEqualToString:kRemindersCalendarTitle]) {
                 return calendar;
             }
         }
    
    //2
    EKCalendar *remindersCalendar =
    [EKCalendar
     calendarForEntityType:EKEntityTypeReminder
     eventStore:self.eventStore];
    
    remindersCalendar.title = kRemindersCalendarTitle;
    remindersCalendar.source =
    self.eventStore.defaultCalendarForNewReminders.source;
    
    NSError *err;
    BOOL success = [self.eventStore
                    saveCalendar:remindersCalendar
                    commit:YES error:&err];
    if (!success) {
        NSLog(@"There was an error creating the reminders calendar");
        return nil;
    }
    return remindersCalendar;
}

- (void) fetchAllConferenceReminders {
    //1
    NSPredicate *predicate =
    [self.eventStore
     predicateForRemindersInCalendars:
     @[[self calendarForReminders]]];
    
    //2
    [self.eventStore
     fetchRemindersMatchingPredicate:predicate
     completion:^(NSArray *reminders){
         
         self.reminders =
         [reminders mutableCopy];
         [[NSNotificationCenter defaultCenter]
          postNotificationName:
          RemindersModelChangedNotification
          object:self];
         
     }];
}

- (void) startBroadcastingModelChangedNotifications {
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(fetchAllConferenceReminders)
     name:EKEventStoreChangedNotification
     object:self.eventStore];
}

- (void) stopBroadcastingModelChangedNotifications {
    [[NSNotificationCenter defaultCenter]
     removeObserver:self];
}

- (void) reminder:(EKReminder*) reminder
setCompletionFlagTo:(BOOL) completionFlag {
    
    //1. Set the completed flag
    //Note: The completion date is automatically
    //      set to the current date
    
    reminder.completed = completionFlag;
    
    //2
    NSError *err;
    BOOL success = [self.eventStore
                    saveReminder:reminder
                    commit:YES error:&err];
    if (!success) {
        NSLog(@"There was an error editing the reminder");
    }
}


@end
