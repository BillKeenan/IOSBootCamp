//
//  ConferenceCell.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 27/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "ConferenceCell.h"

@implementation ConferenceCell
@end
