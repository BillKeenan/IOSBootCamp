//
//  ConferenceDetailViewController.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 28/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "ConferenceDetailViewController.h"
#import "EventKitController.h"

@interface ConferenceDetailViewController () {
    NSArray *_eventTableSections;
    NSDateFormatter *_dateFormatter;
    EventKitController *_eventKitController;
}

@property (nonatomic, weak) IBOutlet UIImageView *image;
@property (nonatomic, weak) IBOutlet UILabel *name, *startDate, *endDate;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@end

@implementation ConferenceDetailViewController

- (id) initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        _eventTableSections = @[@[@"Add event to calendar", @"Add a recurring event", @"Remove all events"], @[@"Add a reminder to buy a ticket", @"Add a reminder to pack your bags"]];
        
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setLocale:[NSLocale currentLocale]];
        [_dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.image setImage:[UIImage imageNamed:self.conference.imageName]];
    [self.name setText:self.conference.name];
    [self.startDate setText:[_dateFormatter stringFromDate:self.conference.startDate]];
    [self.endDate setText:[_dateFormatter stringFromDate:self.conference.endDate]];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _eventTableSections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_eventTableSections [section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EventKitCell"];
    cell.textLabel.text = (_eventTableSections[indexPath.section])[indexPath.row];
    return cell;
}

- (void) performEventOperations {
    NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
    if (indexPath.row == 0) {
        //add code to add an event
        
        [_eventKitController
            addEventWithName:self.conference.name
            startTime:self.conference.startDate
            endTime:self.conference.endDate];
        
    } else if(indexPath.row == 1) {
        //add code to add a recurring event
        
        [_eventKitController
         addRecurringEventWithName:self.conference.name
         startTime:self.conference.startDate
         endTime:self.conference.endDate];
        
    } else if(indexPath.row == 2) {
        //add code to delete an event
        [_eventKitController
         deleteEventWithName:self.conference.name
         startTime:self.conference.startDate
         endTime:self.conference.endDate];
    }

    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void) performReminderOperations {
    NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
    if (indexPath.row == 0) {
        //code to add a reminder to buy a ticket
        [_eventKitController
         addReminderWithTitle:
         [NSString stringWithFormat:@"Buy your %@ ticket",
          self.conference.name]
         dueTime:[NSDate date]];
        
    } else if(indexPath.row == 1) {
        //code to add a reminder to pack your bags
        //1
        NSCalendar *calendar = [NSCalendar currentCalendar];
        
        //2
        NSDateComponents *oneDayComponents =
        [[NSDateComponents alloc] init];
        
        //3
        oneDayComponents.day = -1;
        
        //4
        NSDate *dayBeforeTheEvent = [calendar
                                     dateByAddingComponents:oneDayComponents
                                     toDate:self.conference.startDate
                                     options:0];
        
        //5
        [_eventKitController
         addReminderWithTitle:
         [NSString
          stringWithFormat:
          @"Pack your bags and get ready for %@",
          self.conference.name]
         dueTime:dayBeforeTheEvent];
    }
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void) dealloc {
    [[NSNotificationCenter defaultCenter]
     removeObserver:self];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_eventKitController == nil) {
        _eventKitController = [[EventKitController alloc] init];
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(performReminderOperations)
         name:RemindersAccessGranted
         object:_eventKitController];
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(performEventOperations)
         name:EventsAccessGranted
         object:_eventKitController];
        NSLog(@"w00t");
    } else {
        if (indexPath.section == 0) {
            [self performEventOperations];
        } else {
            [self performReminderOperations];
        }
    }
}
@end
