//
//  ConferenceDetailViewController.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 28/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "ConferenceDetailViewController.h"

@interface ConferenceDetailViewController () {
    NSArray *_eventTableSections;
    NSDateFormatter *_dateFormatter;
}
@property (nonatomic, weak) IBOutlet UIImageView *image;
@property (nonatomic, weak) IBOutlet UILabel *name, *startDate, *endDate;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@end

@implementation ConferenceDetailViewController

- (id) initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        _eventTableSections = @[@[@"Add event to calendar", @"Add a recurring event", @"Remove all events"], @[@"Add a reminder to buy a ticket", @"Add a reminder to pack your bags"]];
        
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setLocale:[NSLocale currentLocale]];
        [_dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.image setImage:[UIImage imageNamed:self.conference.imageName]];
    [self.name setText:self.conference.name];
    [self.startDate setText:[_dateFormatter stringFromDate:self.conference.startDate]];
    [self.endDate setText:[_dateFormatter stringFromDate:self.conference.endDate]];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _eventTableSections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_eventTableSections [section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EventKitCell"];
    cell.textLabel.text = (_eventTableSections[indexPath.section])[indexPath.row];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            //add code to add an event
            
        } else if(indexPath.row == 1) {
            //add code to add a recurring event
            
        } else if(indexPath.row == 2) {
            //add code to delete an event
            
        }
    } else if(indexPath.section == 1) {
        if (indexPath.row == 0) {
            //code to add a reminder to buy a ticket
            
        } else if(indexPath.row == 1) {
            //code to add a reminder to pack your bags
        }
    }
}
@end
