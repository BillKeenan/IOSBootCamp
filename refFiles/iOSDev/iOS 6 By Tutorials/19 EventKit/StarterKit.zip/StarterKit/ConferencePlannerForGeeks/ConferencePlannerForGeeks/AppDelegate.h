//
//  AppDelegate.h
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 25/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
