//
//  ConferenceDetailViewController.h
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 28/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//
#import "Conference.h"

@interface ConferenceDetailViewController : UIViewController
@property (nonatomic, strong) Conference *conference;
@end
