//
//  ConferenceCell.h
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 27/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

@interface ConferenceCell : UITableViewCell
@property (nonatomic, strong) IBOutlet UILabel *nameLabel;
@property (nonatomic, strong) IBOutlet UIImageView *conferenceImageView;
@end
