//
//  AppDelegate.m
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 25/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

#import "AppDelegate.h"
#import "ConferencesViewController.h"
#import "Conference.h"

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"conferences" ofType:@"plist"]];
    NSMutableArray *conferences = [[NSMutableArray alloc] initWithCapacity:array.count];

    for (NSDictionary *dictionary in array) {
        Conference *conference = [[Conference alloc] init];
        conference.name = [dictionary objectForKey:@"Name"];
        conference.imageName = [dictionary objectForKey:@"ImageName"];
        conference.startDate = [dictionary objectForKey:@"StartDate"];
        conference.endDate = [dictionary objectForKey:@"EndDate"];
        [conferences addObject:conference];
    }
    
    //go through the view controllers and set the data source
    UITabBarController *tabBarController = (UITabBarController*)self.window.rootViewController;
    UINavigationController *navigationController = (UINavigationController*)[tabBarController viewControllers][0];
    ConferencesViewController *conferencesViewController = (ConferencesViewController*)[navigationController viewControllers][0];
    conferencesViewController.conferences = conferences;
    return YES;
}
@end
