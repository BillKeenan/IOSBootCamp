//
//  Conference.h
//  ConferencePlannerForGeeks
//
//  Created by Kauserali on 27/06/12.
//  Copyright (c) 2012 raywenderlich. All rights reserved.
//

@interface Conference : NSObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSDate *startDate;
@property (nonatomic, copy) NSDate *endDate;
@end
