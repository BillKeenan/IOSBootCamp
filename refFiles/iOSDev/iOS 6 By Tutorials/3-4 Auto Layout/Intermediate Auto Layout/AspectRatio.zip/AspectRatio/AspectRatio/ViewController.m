
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
	UIImageView *_photoView;
}

- (void)viewDidLoad
{
	[super viewDidLoad];

	UIImage *image = [UIImage imageNamed:@"Photo"];

	_photoView = [[UIImageView alloc] initWithImage:image];
	_photoView.translatesAutoresizingMaskIntoConstraints = NO;
	_photoView.backgroundColor = [UIColor redColor];

	[self.view addSubview:_photoView];

	// photoView.centerX = self.view.centerX

	NSLayoutConstraint *constraint = [NSLayoutConstraint
		constraintWithItem:_photoView
		attribute:NSLayoutAttributeCenterX
		relatedBy:NSLayoutRelationEqual
		toItem:self.view
		attribute:NSLayoutAttributeCenterX
		multiplier:1.0f
		constant:0.0f];

	[self.view addConstraint:constraint];

	// photoView.centerY = self.view.centerY

	constraint = [NSLayoutConstraint
		constraintWithItem:_photoView
		attribute:NSLayoutAttributeCenterY
		relatedBy:NSLayoutRelationEqual
		toItem:self.view
		attribute:NSLayoutAttributeCenterY
		multiplier:1.0f
		constant:0.0f];

	[self.view addConstraint:constraint];

	// photoView.height = self.view.height

	constraint = [NSLayoutConstraint
		constraintWithItem:_photoView
		attribute:NSLayoutAttributeHeight
		relatedBy:NSLayoutRelationEqual
		toItem:self.view
		attribute:NSLayoutAttributeHeight
		multiplier:1.0f
		constant:0.0f];

	[self.view addConstraint:constraint];

	// photoView.height = 1.5 * photoView.width

	constraint = [NSLayoutConstraint
		constraintWithItem:_photoView
		attribute:NSLayoutAttributeHeight
		relatedBy:NSLayoutRelationEqual
		toItem:_photoView
		attribute:NSLayoutAttributeWidth
		multiplier:1.5f
		constant:0.0f];

	[_photoView addConstraint:constraint];
}

@end
