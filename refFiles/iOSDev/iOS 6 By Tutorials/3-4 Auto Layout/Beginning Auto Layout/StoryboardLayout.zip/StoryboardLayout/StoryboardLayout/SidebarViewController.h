//
//  SidebarViewController.h
//  StoryboardLayout
//
//  Created by Fahim Farook on 29/7/12.
//  Copyright (c) 2012 RookSoft Pte. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SidebarViewController : UIViewController

@end
