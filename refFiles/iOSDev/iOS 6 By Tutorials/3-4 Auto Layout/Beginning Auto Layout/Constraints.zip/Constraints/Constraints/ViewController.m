//
//  ViewController.m
//  Constraints
//
//  Created by Fahim Farook on 27/7/12.
//  Copyright (c) 2012 RookSoft Pte. Ltd. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, weak) IBOutlet UILabel *artistNameLabel;
@property (nonatomic, weak) IBOutlet UILabel *releaseYearLabel;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)nextButtonTapped:(id)sender
{
    static NSArray *artists;
    if (artists == nil)
    {
        artists = @[ @"Thelonious Monk", @"Miles Davis", @"Louis Jordan & His Tympany Five", @"Charlie 'Bird' Parker", @"Chet Baker" ];
    }
	
    static int index = 0;
	
    self.artistNameLabel.text = artists[index % 5];
	
    index++;
}

@end
