//
//  GuildTests.h
//  GuildBrowser
//
//  Created by Charlie Fulton on 9/15/12.
//  Copyright (c) 2012 Charlie Fulton. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface GuildTests : SenTestCase

@end
