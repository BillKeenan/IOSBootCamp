// 1
var target = UIATarget.localTarget();
var app = target.frontMostApp();
var window = app.mainWindow();
var navBar = window.navigationBar();



//2
// make sure we see the correct guild on app start
var testGroup = "verify guild is correct"

// 3
UIALogger.logStart(testGroup)

// pause for app to start and load data from network
target.delay(5);

var currentGuildName = navBar.staticTexts()[0].name();

// 4
if (currentGuildName != "Dream Catchers") {
	UIALogger.logError("The wrong guild is showing: currentGuildName == " + currentGuildName);
	UIALogger.logFail(testGroup);
} else {
	UIALogger.logMessage("We found the correct guild yay!");
	// 5
	// take a screenshot
	target.captureScreenWithName("guild");
    
    // 6 debug view hierarchy
    target.logElementTree();
	UIALogger.logPass(testGroup);
}

// 1
testGroup = "CharacterDetail Screen Test";
UIALogger.logStart(testGroup);
UIALogger.logMessage("Selecting Xofy");

// 2
var collectionView = window.collectionViews()[0];


// see what we currently look like
target.captureScreenWithName("app loaded screenshot");

UIALogger.logMessage("Kicking a gnome!");

// 3
character = collectionView.cells().firstWithName("Xofy");
character.tap();
character.waitForInvalid();

target.captureScreenWithName("Xofy - Character Detail");

// 4
var toolbarTitle = window.toolbar().staticTexts()[0].name()

if (toolbarTitle != "Bloodsail Admiral Xofy") {
	UIALogger.logError("We are kicking the wrong gnome");
	UIALogger.logFail(testGroup);
} else {
	UIALogger.logMessage("Woot boot a gnome!");
	UIALogger.logPass(testGroup);
}

// now close character detail screen
target.frontMostApp().toolbar().buttons()["Close"].tap();


testGroup = "ChangeGuild";
UIALogger.logStart(testGroup);
UIALogger.logMessage("Selecting a new guild");

// 1
navBar.rightButton().tap();
target.frontMostApp().mainWindow().popover().textFields()[0].setValue("Fishsticks")
// 2
target.tap({x:322.00, y:252.00});
target.delay(4);

currentGuildName = navBar.staticTexts()[0].name();

if (currentGuildName != "Fishsticks") {
	UIALogger.logError("The wrong guild is showing");
	UIALogger.logFail(testGroup);
} else {
	UIALogger.logMessage("We found the correct guild yay!");
	target.captureScreenWithName("guild");
	UIALogger.logPass(testGroup);
}
