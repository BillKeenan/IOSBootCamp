//
//  GuildBrowserTests.m
//  GuildBrowserTests
//
//  Created by Charlie Fulton on 8/25/12.
//  Copyright (c) 2012 Charlie Fulton. All rights reserved.
//

#import "GuildBrowserTests.h"

@implementation GuildBrowserTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
   // STFail(@"Unit tests are not implemented yet in GuildBrowserTests");
}

@end
