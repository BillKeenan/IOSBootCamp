//
//  GuildBrowserTests.h
//  GuildBrowserTests
//
//  Created by Charlie Fulton on 8/25/12.
//  Copyright (c) 2012 Charlie Fulton. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface GuildBrowserTests : SenTestCase

@end
