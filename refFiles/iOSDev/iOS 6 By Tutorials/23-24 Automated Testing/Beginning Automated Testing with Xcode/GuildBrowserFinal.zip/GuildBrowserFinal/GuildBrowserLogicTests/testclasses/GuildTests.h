#import <SenTestingKit/SenTestingKit.h>

@interface GuildTests : SenTestCase

@end
