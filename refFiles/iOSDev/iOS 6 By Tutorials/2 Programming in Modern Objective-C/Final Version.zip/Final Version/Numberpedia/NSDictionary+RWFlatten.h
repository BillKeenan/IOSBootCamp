
@interface NSDictionary (RWFlatten)

- (NSArray *)rw_flattenIntoArray;

@end
