<?php

//1 VERY simple input validation
if (strlen($_POST['year'])<4 || strlen($_POST['email'])<6 ||
 strlen($_POST['location'])<1) {
  header("Location: index.php?message=Enter valid data");
  exit();
}

//2 check for correct answer
if ($_POST['year']!="2003") {
  header("Location: index.php?message=That was not the correct answer, try again");
  exit();
}

//predefine store locations
$locations = array(
  array("latitude"=>52.402419,"longitude"=>12.970734),
  array("latitude"=>52.491231,"longitude"=>13.430362),
  array("latitude"=>52.481921,"longitude"=>13.433458),
  array("latitude"=>52.481967,"longitude"=>13.431993,
        "altitude"=>30.0)
);

//create new pass instance
require_once("Pass.php");
$coupon = new Pass("pass/source");

//fill in dynamic data
$coupon->content['serialNumber'] = (string)uniqid();
$coupon->content['coupon']['secondaryFields'][0]['value'] = 
    (string)$_POST['name'];
$coupon->content['locations'][0] = 
   $locations[(int)$_POST['location']];
        
$coupon->writePassJSONFile();

$coupon->writeRecursiveManifest();
$coupon->writeSignatureWithKeysPathAndPassword("pass", '12345');
$fileName = $coupon->writePassBundle();

//send over the pass file
require_once("lib.php");

$success = sendFileToEmailWithTitleAndMessage(
      $_POST['email'], 
      "Your coupon has arrived", 
      $_POST['name'].", Thank you for participating!", 
      "noreply@yourdomain.com",
      $fileName);

//show thank you message
header("Location: index.php?message=Thank you for participating in our bonus program. <br/>Your coupon has been sent to ".$_POST['email']);

?>
