<?php
class Pass {
	private $workFolder = null;
	private $ID = null;
	
	var $content = null;
	var $passBundleFile = null;

	private function copySourceFolderFilesToWorkFolder($path) {
	  //recurse over contents and copy files
	  $files = new RecursiveIteratorIterator(
	                 new RecursiveDirectoryIterator($path), 
	                 RecursiveIteratorIterator::SELF_FIRST);
	  
	  foreach($files as $name => $fileObject){
	    if (is_file($name) && 
	        substr($fileObject->getFileName(), 0, 1)!=".") {
	
	      copy($name, 
	        $this->workFolder."/".str_replace($path."/", "",$name));
	    } else if (is_dir($name)) {
	      mkdir($this->workFolder."/".
	            str_replace($path."/", "",$name));
	    }
	  }
	}
	
	//import a json file into the object
	function readPassFromJSONFile($filePath) {
	  //read the json file and decode to an object
	  $this->content = 
	     json_decode(file_get_contents($filePath),true);
	}
	
	//export a json file from the object
	function writePassJSONFile() {
	  file_put_contents($this->workFolder."/pass.json",
	                    json_encode($this->content));
	}

	//generate the manifest file
	function writeRecursiveManifest() {
	  //create empty manifest
	  $manifest = new ArrayObject();
	  
	  //recurse over contents and build the manifest
	  $files = new RecursiveIteratorIterator(
	             new RecursiveDirectoryIterator($this->workFolder), 
	             RecursiveIteratorIterator::SELF_FIRST);
	  
	  foreach($files as $name => $fileObject){
	    if (is_file($name) && 
	          substr($fileObject->getFileName(), 0, 1)!=".") {
	
	      $relativeName = str_replace($this->workFolder.
	                                    "/","",$name);
	      
	      $sha1 = sha1(file_get_contents(
	                     $fileObject->getRealPath()
	              ));
	      $manifest[$relativeName] = $sha1;
	    }
	  }
	  
	  //write the manifest file
	  file_put_contents($this->workFolder."/manifest.json",
	                      json_encode($manifest));
	}
	
	//generate the bundle signature
	function writeSignatureWithKeysPathAndPassword($keyPath, $pass) {
	  $keyPath = realpath($keyPath);
	  
	  if (!file_exists($keyPath.'/WWDR.pem')) 
	    die("Save the WWDR certificate as 
	         $keyPath/WWDR.pem");
	  
	  if (!file_exists($keyPath.'/passcertificate.pem')) 
	    die("Save the pass certificate as 
	         $keyPath/passcertificate.pem");
	    
	  if (!file_exists($keyPath.'/passkey.pem')) 
	    die("Save the pass certificate key as 
	         $keyPath/passkey.pem");
	  
	  $output = shell_exec("openssl smime -binary -sign".
	  	" -certfile '".$keyPath."/WWDR.pem'".
	    " -signer '".$keyPath."/passcertificate.pem'".
	    " -inkey '".$keyPath."/passkey.pem'".
	    " -in '".$this->workFolder."/manifest.json'".
	    " -out '".$this->workFolder."/signature'".
	    " -outform DER -passin pass:'$pass'");
	}
	
	//create the zip bundle from the pass files
	function writePassBundle() {  
	  //1 generate the name for the .pkpass file
	  $passFile = $this->workFolder."/".$this->ID.".pkpass";
	
	  //2 create Zip class instance
	  $zip = new ZipArchive();
	  $success = $zip->open($passFile, ZIPARCHIVE::OVERWRITE);
	  if ($success!==TRUE) die("Can't create file $passFile");
	  
	  //3 recurse over contents and build the list
	  $files = new RecursiveIteratorIterator(
	             new RecursiveDirectoryIterator($this->workFolder), 
	             RecursiveIteratorIterator::SELF_FIRST);
	  
	  //4 add files to the archive
	  foreach($files as $name => $fileObject){
	    if (is_file($name) && 
	        substr($fileObject->getFileName(), 0, 1)!=".") {
	      
	      $relativeName = str_replace($this->workFolder."/", 
	                                  "",$name);
	      $zip->addFile($fileObject->getRealPath(), $relativeName);
	    }
	  }
	  
	  //5 close the zip file
	  $zip->close();  
	  
	  //6 save the .pkpass file path and return it too
	  $this->passBundleFile = $passFile;
	  return $passFile;
	}
	
	//make new instance from a source folder
	function __construct($path) {
	  assert(file_exists($path."/pass.json"));
	  
	  $this->ID = uniqid();
	  
	  $this->workFolder = sys_get_temp_dir()."/".$this->ID;
	  mkdir($this->workFolder);
	  assert(file_exists($this->workFolder));
	  
	  $this->copySourceFolderFilesToWorkFolder($path);
	  
	  $this->readPassFromJSONFile($this->workFolder."/pass.json");  
	}
	
	//delete all auto-generated files in the temp folder
	function cleanup()
	{
	  //recurse over contents and delete files
	  $files = new RecursiveIteratorIterator(
	             new RecursiveDirectoryIterator($this->workFolder), 
	             RecursiveIteratorIterator::CHILD_FIRST);
	  
	  foreach($files as $name => $fileObject){
	    if (is_file($name)) {
	      unlink($name);
	    } else if (is_dir($name)) {
	      rmdir($name);
	    }
	  }
	  
	  rmdir($this->workFolder);
	}
	
	//cleanup the temp folder on object destruction
	function __destruct() {
	  $this->cleanup();
	}
}

?>
