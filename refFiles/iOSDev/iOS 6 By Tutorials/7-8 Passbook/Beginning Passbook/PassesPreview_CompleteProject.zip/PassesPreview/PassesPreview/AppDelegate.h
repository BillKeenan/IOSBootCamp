//
//  AppDelegate.h
//  PassesPreview
//
//  Created by Fahim Farook on 21/7/12.
//  Copyright (c) 2012 Your Organization. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
