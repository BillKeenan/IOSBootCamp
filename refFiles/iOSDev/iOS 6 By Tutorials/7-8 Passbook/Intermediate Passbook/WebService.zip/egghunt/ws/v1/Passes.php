<?php
require_once(dirname(__FILE__)."/../../class/Database.php");

class Passes {

//takes in the request URL parameters and creates a response
function __construct($params) {
  
  //detect the HTTP method - can be get, post or delete
  $method = strtolower($_SERVER['REQUEST_METHOD']);
  
  //switch between the list of valid requests or return 401
  switch ($method) {
    case "get":
    $this->getPass($params);
    break;
    
    default: //not a valid web service call
    httpResponseCode(401);exit();
    break;
  }
}

//download the pass with given
//authentication token and serial number
private function getPass($params) {
	$passTypeID = $params[3];
	$serialNr   = $params[4];
	
	$headers = getallheaders();
	$authenticationToken = str_replace("ApplePass ", "", $headers['Authorization']);
	$ifModifiedSince = $headers['If-Modified-Since'];
	
	$db = Database::get();
	//select the pass with the given details
	$statement = $db->prepare("SELECT * FROM passes WHERE passTypeID = ? AND serialNr = ? AND authenticationToken = ?");
	
	$statement->execute(array($passTypeID, $serialNr, $authenticationToken));
	
	//try to fetch the pass from the database
	$row = $statement->fetch(PDO::FETCH_ASSOC);
	//check if a matching pass was found
	if (!$row) {
		//no pass was found
		httpResponseCode(401);exit();
	}
	//check if the pass was modified on the server
	if ($ifModifiedSince >= $row['lastUpdated']) {
		//the pass was not modified
		httpResponseCode(304);exit();
	}
	//provide the last modified time to the client
	header("Last-modified: ".$row['lastUpdated'], true);
	//create a new pass instance with the latest data
	require_once("../class/EggHuntPass.php");
	$pass = EggHuntPass::passWithSerialNr($serialNr);
	  
	//output the pass contents to the client
	$pass->outputPassBundleAsWebDownload();
	  
	exit();

}

}
?>