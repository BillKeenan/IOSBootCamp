<?php

require_once(dirname(__FILE__)."/../../class/Database.php");

class Devices {

//takes in the request URL parameters and creates a response
function __construct($params) {
	//detect the HTTP method - can be get, post or delete
	$method = strtolower($_SERVER['REQUEST_METHOD']);
	$action = strtolower($params[4]);
	
	//switch between the list of valid requests or return 401
	switch ($method.":".$action) {
		case "post:registrations":
			$this->createRegistration($params);
			break;
		
		case "delete:registrations":
			$this->deleteRegistration($params);
			break;
		
		case "get:registrations":
			$this->getDeviceUpdates(
			$params, @(int)$_GET['passesUpdatedSince']);
			break;
		
		default: //not a valid web service call
			httpResponseCode(401);
			exit();
			break;
	}
} 

//register device with ID for a pass instance
private function createRegistration($params) {
	$deviceID   = $params[3];
	$passTypeID = $params[5];
	$serialNr   = $params[6];
	$payload    = json_decode(file_get_contents('php://input'),true);
	$pushToken  = $payload['pushToken'];
	$headers    = getallheaders();
	$authenticationToken = str_replace("ApplePass ","", $headers['Authorization']);
	
	$db = Database::get();
	//check authorization token
	$statement = $db->prepare("SELECT COUNT(*) FROM passes WHERE passTypeID=? AND serialNr=? AND authenticationToken=?");
	$statement->execute(array($passTypeID, $serialNr, $authenticationToken));
	if ($statement->fetchColumn() == 0) {
		//no such pass found in the database
		httpResponseCode(401);
		exit();
	}

	//check for existing registration 
	$statement = $db->prepare("SELECT COUNT(*) FROM devices WHERE device=? AND serialNr=?");
	$statement->execute(array($deviceID, $serialNr));
	if ($statement->fetchColumn() == 0) {
		//insert the registration in the database
		$stmtInsert = $db->prepare("INSERT INTO devices (device, pushToken, serialNr) values (?, ?, ?)");
		$stmtInsert->execute(array($deviceID, $pushToken, $serialNr));
		httpResponseCode(201);
	} else {
		//update the pushToken of the existing registration
		$stmtUpdate = $db->prepare("UPDATE devices SET pushToken=? WHERE device=? AND serialNr=?");
		$stmtUpdate->execute(array($pushToken, $deviceID, $serialNr));
		httpResponseCode(200);
	}
	exit();
}

//delete device with ID
private function deleteRegistration($params) {
	$deviceID   = $params[3];
	$passTypeID = $params[5];
	$serialNr   = $params[6];
	$headers    = getallheaders();
	$authenticationToken = str_replace("ApplePass ", "", $headers['Authorization']);
	
	$db = Database::get();
	//check authorization token
	$statement = $db->prepare("SELECT COUNT(*) FROM passes WHERE passTypeID=? AND serialNr=? and authenticationToken=?");
	$statement->execute(array($passTypeID, $serialNr, $authenticationToken));
	if ($statement->fetchColumn() == 0) {
		//no such registration found in the database
		httpResponseCode(401);
		exit();
	}
	
	//delete the registration from devices
	$statement = $db->prepare("DELETE FROM devices WHERE device=? AND serialNr=?");
	$statement->execute(array($deviceID, $serialNr));
	httpResponseCode(200);
	exit();
}

//get list of pass updates for a device ID
private function getDeviceUpdates($params, $updateTag) {
	$deviceID = $params[3];
	$passTypeID = $params[5];
	
	$db = Database::get();
	
	//grab the updated serial numbers
	$statement = $db->prepare("SELECT passes.serialNr, lastUpdated FROM passes JOIN devices on (devices.serialNr = passes.serialNr) WHERE passTypeID = ? AND lastUpdated > ? AND device = ?");
	
	$statement->execute(array($passTypeID, $updateTag, $deviceID));
  
	$serialList = array(); //1
	$newUpdateTag = 0; //2
	//3 loop and get the the update tag of the latest updated pass
	//also add all serials into an array
	while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
		$serialList[] = $row['serialNr'];
		if ($row['lastUpdated']>$newUpdateTag) {
			$newUpdateTag = $row['lastUpdated']; //4
		}
	}
	//if there were no passes updated, return the proper response
	if (count($serialList)==0) {
		//check whether device is registered at all
		$statement = $db->prepare("SELECT COUNT(*) FROM devices WHERE device = ?");
		$statement->execute(array($deviceID));
		if ($statement->fetchColumn() == 0) {
			//device not registered
			httpResponseCode(404);
		} else {
			//no pass updates
			httpResponseCode(204);
		}
		exit();
	}
	//prepare the response
	$response = new ArrayObject();
	$response['serialNumbers'] = $serialList;
	$response['lastUpdated'] = $newUpdateTag;
	//return JSON encoded response
	print(json_encode($response));
	exit();
}

}
?>