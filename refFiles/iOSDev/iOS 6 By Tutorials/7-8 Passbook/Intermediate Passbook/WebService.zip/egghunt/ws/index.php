<?php
require_once("lib.php");

//get the request parameters out of the request URL
$requestURL = (($_SERVER['REDIRECT_URL']!="") ? $_SERVER['REDIRECT_URL'] : $_SERVER['REQUEST_URI']);
$scriptPath  = dirname($_SERVER['PHP_SELF']);

$requestURL = str_replace($scriptPath, "",$requestURL );
$requestParts = explode("/",$requestURL);

//check for valid API version
$validAPIVersions = array("v1");
$apiVersion = $requestParts[1];
if (!in_array($apiVersion, $validAPIVersions)) {
	httpResponseCode(404);
	exit();
}

//check for valid API endpoint
$validEndPoints = array("devices","passes","log");
$endPoint = $requestParts[2];
if (!in_array($endPoint, $validEndPoints)) {
	httpResponseCode(404);exit();
}

//get the endpoint class name
$endPoint = ucfirst(strtolower($endPoint));
$classFilePath = "$apiVersion/$endPoint.php";
if (!file_exists($classFilePath)) {
  httpResponseCode(404);exit();
}

//load the endpoint class and make an instance
try {
	require_once($classFilePath);
	$instance = new $endPoint($requestParts);
} catch (Exception $e) {
	//save $e->getMessage() to a log file
	httpResponseCode(500);
}

exit();

?>