<?php

class Log {

//takes in the request URL parameters and creates a response
function __construct($params) {
	$method = strtolower($_SERVER['REQUEST_METHOD']);
	switch ($method) {
		//save a message to the log
		case "post":
			$this->saveLog();
			break;
		
		default:
			//not valid request parameters
			httpResponseCode(401);
			exit();
			break;
	}
}

private function saveLog() {
	//read the POST data and decode the JSON
	$payload = json_decode(file_get_contents('php://input'), true);
	
	//validate the input
	if ($payload && $payload['logs']) {
		$emailFrom = "noreply@yourdomain.com";
		$emailTo = "you@yourdomain.com";
		mail($emailTo, "Apple Pass Service Log", "Log message on " . date("Y-m-d H:i:s") . "\n" . print_r($payload['logs'], true), 
		"From: " . $emailFrom);
	}
}

}
