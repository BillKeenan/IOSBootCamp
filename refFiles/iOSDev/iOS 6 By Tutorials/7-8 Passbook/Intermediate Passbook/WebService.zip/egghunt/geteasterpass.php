<?php
require_once("class/EggHuntPass.php");

//generate a new pass
$coupon = EggHuntPass::createPassWithUniqueSerialNr($error);

if ($coupon!=null) {
  //send it over to the client
  $coupon->outputPassBundleAsWebDownload();
} else {
  //there was an error
  die("Error: ".$error);
}
?>