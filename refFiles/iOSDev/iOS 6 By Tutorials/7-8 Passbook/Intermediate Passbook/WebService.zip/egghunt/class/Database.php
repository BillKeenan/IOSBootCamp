<?php

class Database extends PDO
{

//database connection details
static private $host   = "localhost";
static private $dbname = "egghunt";
static private $user   = "user";
static private $pass   = "password";

private static $instance = null;

//get the singleton instance
static function get() {
  if (self::$instance!=null) return self::$instance;
  
  try {
    self::$instance = new Database("mysql:host=".self::$host.";dbname=".self::$dbname, self::$user, self::$pass);
    return self::$instance;
  }
  catch(PDOException $e) {
      print $e->getMessage();
      return null;
  }
}

}
?>