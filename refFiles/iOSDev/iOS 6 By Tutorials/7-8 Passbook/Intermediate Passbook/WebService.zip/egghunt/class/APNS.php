<?php
require_once("Database.php");

class APNS {

//config for generating passes
private $keyPath = 'pass';
private $keyPassword = "123";

//apple push service endpoint
private $apnsHost = 'ssl://gateway.push.apple.com:2195';

function __construct() {
	$this->keyPath = realpath(dirname(__FILE__) . "/../" . $this->keyPath);
}

//update all registered devices
function updateAllPasses() {
	$db = Database::get();
	$statement = $db->prepare("SELECT pushToken FROM devices");
	$statement->execute();
	$this->sendPushesToResultSet($statement);
	return $statement->rowCount();
}

//update all devices which have the given pass installed
function updateForPassWithSerialNr($serialNr) {
	$db = Database::get();
	$statement = $db->prepare("SELECT pushToken FROM devices WHERE serialNr=?");
	$statement->execute(array($serialNr));
	$this->sendPushesToResultSet($statement);
}

//send push notifications to all devices in the result set
private function sendPushesToResultSet(PDOStatement $stmt) {
	//check if there are any results
	if ($stmt->rowCount()==0) 
		return;
	//open connection to apns
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', $this->keyPath."/passcertbundle.pem");
	stream_context_set_option($ctx, 'ssl', 'passphrase', $this->keyPassword);
	$fp = stream_socket_client($this->apnsHost, $err, $errstr, 15, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
	if (!$fp) 
		return; //TODO: add error handling
	//create an empty push
	$emptyPush = json_encode(new ArrayObject());
	//send it to all devices found
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		//write the push message to the apns socket connection
		$msg = chr(0). //1
		pack("n",32).
		pack('H*', $row['pushToken']). //2
		pack("n",strlen($emptyPush)). //3
		$emptyPush; //4
		fwrite($fp, $msg);
	}
	//close the apns connection
	fclose($fp);
}

}
?>