<?php

require_once("Pass.php");
require_once("Database.php");

//EggHuntPass is a more concrete
//pass class implementation
class EggHuntPass extends Pass {

// 1) the pass configuration is 
// bundled in the class
private $keyPath = "pass";
private $sourcePath = "pass/source";
private $keyPassword = "12345";

static $passTypeID = "pass.org.farook.couponfreehug";


// 2) autoconfigures the object and 
// calls the original Pass constructor
function __construct() {
	$this->keyPath = realpath(dirname(__FILE__) . "/../".$this->keyPath);
	$this->sourcePath = realpath(dirname(__FILE__) . "/../".$this->sourcePath);
	parent::__construct($this->sourcePath);
}

//calls all Pass methods one after another
//because all the configuration is bundled with the class
function writeAllFiles() {
	$this->writePassJSONFile();
	$this->writeRecursiveManifest();
	$this->writeSignatureWithKeysPathAndPassword($this->keyPath, $this->keyPassword);
	$this->writePassBundle();
}

//1) create a new game pass with unique serial number
static function createPassWithUniqueSerialNr(&$error) {
	//2) get new instance
	$pass = new EggHuntPass();
	//3) fill in the details
	$pass->content['passTypeIdentifier'] = self::$passTypeID;
	$pass->content['authenticationToken'] = sha1(mt_rand().microtime(true));
	$pass->content['serialNumber'] = (string)round(microtime(true)*100);
	$pass->content['barcode']['message'] = (string)round(microtime(true)*100) . mt_rand(10000,99999);
	$pass->content['generic']['primaryFields'][0]['value'] = sprintf("$ %.2f", 0);
	
	//generate the next location field
	$nextLocation = self::getCurrentBunnyLocation();
	$pass->content['generic']['secondaryFields'][0]['value'] = $nextLocation['value'];
	$pass->content['generic']['secondaryFields'][0]['changeMessage']= $nextLocation['changeMessage'];
	if (isset($nextLocation['label'])) {
		$pass->content['generic']['secondaryFields'][0]['label'] = $nextLocation['label'];
	}
	if (isset($nextLocation['location'])) {
		$pass->content['locations'] = array($nextLocation['location']);
		$pass->content['relevantDate'] = date("c");      
	}
	
	//get database connection
	$db = Database::get();
	try {
		//insert the pass record in the database
		$statement = $db->prepare("INSERT INTO passes(serialNr, authenticationToken, lastUpdated, credit, barcode, passTypeID) VALUES(?,?,?,?,?,?)");
		$statement->execute(array(
			$pass->content['serialNumber'],
			$pass->content['authenticationToken'],
			time(), //last update is now
			0, //initial credit is 0
			$pass->content['barcode']['message'],
			self::$passTypeID
		));
		if ($statement->rowCount()!=1) 
			throw new PDOException("Could not create a pass in the database");
	} catch (PDOException $e) {
		$error= $e->getMessage();
		return null;
	}

	//4) save the pass bundle
	$pass->writeAllFiles();
	
	//5) return the pass object
	return $pass;
}

//get a pass instance for a given serialNr
static function passWithSerialNr($serialNr) {
	$pass = new EggHuntPass();
	
	//load the pass data from the database
	$db = Database::get();
	$statement = $db->prepare("SELECT * FROM passes WHERE serialNr = ?");
	$statement->execute(array($serialNr));
	
	$row = $statement->fetch(PDO::FETCH_ASSOC);
	
	if (!$row) {
		//no pass with such serialNr found
		return null;
	}
  
	//generate the pass
	$pass->content['serialNumber'] = $row['serialNr'];
	$pass->content['authenticationToken'] = $row['authenticationToken'];
	$pass->content['barcode']['message'] = $row['barcode'];
	$pass->content['passTypeIdentifier'] = self::$passTypeID;
	$pass->content['generic']['primaryFields'][0]['value'] = sprintf("$ %.2f", $row['credit']);
	//generate the next location field
	$nextLocation = self::getCurrentBunnyLocation();
	$pass->content['generic']['secondaryFields'][0]['value'] = $nextLocation['value'];
	$pass->content['generic']['secondaryFields'][0]['changeMessage']= $nextLocation['changeMessage'];
	if (isset($nextLocation['label'])) {
		$pass->content['generic']['secondaryFields'][0]['label'] = $nextLocation['label'];
	}
	if (isset($nextLocation['location'])) {
		$pass->content['locations'] = array($nextLocation['location']);
		$pass->content['relevantDate'] = date("c");      
	}

	//save the pass bundle
	$pass->writeAllFiles();
	
	//return the pass instance
	return $pass;
}

//get the data for the location field of the pass
//according to whether the bunny is in a store or not
static function getCurrentBunnyLocation() {
	$db = Database::get();
	
	//get the current location
	$statement = $db->prepare("SELECT * FROM locations WHERE isBunnyHere=1");
	$statement->execute();
	$currentLocation = $statement->fetch(PDO::FETCH_ASSOC);
	//prepare the method result
	$nextLocation = new ArrayObject();
	
	if ($currentLocation) {
		//the bunny is in a store
		$nextLocation['value'] = $currentLocation['store'];
		$nextLocation['changeMessage'] = "Next Easter Bunny in %@";
		$nextLocation['location'] = new ArrayObject();
		$nextLocation['location']['latitude'] = (double)$currentLocation['lat'];
		$nextLocation['location']['longitude'] = (double)$currentLocation['lon'];
		if ($currentLocation['alt']>0) {
			$nextLocation['location']['altitude'] = (double)$currentLocation['alt'];
		}
		$nextLocation['location']['relevantText'] = "Look in ".$currentLocation['store']."!";
		return $nextLocation;
	}
	//check whether the game is still active
	$statement = $db->prepare("SELECT * FROM egghunt");
	$statement->execute();
	$gameStatus = $statement->fetch(PDO::FETCH_ASSOC);
	if ($gameStatus['hasGameFinished']==1) {
		//game finished
		$nextLocation['value'] = "Spend your store credit!";
		$nextLocation['label'] = "The Easter Egg Hunt has finished";
		$nextLocation['changeMessage'] = "%@";
	} else {
		//just wait for the next bunny location
		$nextLocation['value'] = "Wait for the next bunny location";
		$nextLocation['changeMessage'] = "%@";
	}
	return $nextLocation;
}

}
?>