<?php
//you'll be returning JSON data
header("Content-type: application/json");

//the bunny app shared secret
$bunnyToken = "askd873kjanf92n4ll298fkjwf923kjb235k23jb";

//read the POST payload
$payload = json_decode(file_get_contents('php://input'), true);

//read the token sent from the client
$token = @$payload["token"];

//check the validity of the token
if ($token!=$bunnyToken) {
	print json_encode(array("msg"=>"Not authorized"));
	exit();
}

//get a database connection
require_once("../class/Database.php");
$db = Database::get();

//check whether the game is currently active
$statement = $db->prepare("SELECT * FROM egghunt LIMIT 1");
$statement->execute();
$egghunt = $statement->fetch(PDO::FETCH_ASSOC);

if ($egghunt['isGameOn']!=1 || $egghunt['hasGameFinished']!=0) {
  print json_encode(array(
    "msg"=>"The Egg Hunt Game is not active at the moment"
  ));
  exit();
}
//check if a bunny is in a store right now
$statement = $db->prepare("SELECT * FROM locations WHERE isBunnyHere=1");
$statement->execute();
$currentLocation = $statement->fetch(PDO::FETCH_ASSOC);
if (!$currentLocation) {
  print json_encode(array(
    "msg"=>"There's no active location at the moment"
  ));
  exit();
}

//update the credit amount of the pass
$barcode = $payload['barcode'];
$statement = $db->prepare("UPDATE passes SET credit = credit + 25, lastUpdated = ? WHERE barcode = ? LIMIT 1");
$statement->execute(array(time(),$barcode));
if ($statement->rowCount()==0) {
  print json_encode(array("msg"=>"Pass not found"));
  exit();
}

// indicate the bunny has been found at the current location
$db->prepare("UPDATE locations SET isBunnyHere=0")->execute();
//update game state
if ($egghunt['bunniesLeft']>0) {
  $statement = $db->prepare("UPDATE egghunt SET bunniesLeft=bunniesLeft-1")->execute();
} else {
  $statement = $db->prepare("UPDATE egghunt SET hasGameFinished=1,isGameOn=0")->execute();
}
//read the pass data
$statement = $db->prepare("SELECT * FROM passes WHERE barcode = ? LIMIT 1");
$statement->execute(array($barcode));
$pass = $statement->fetch(PDO::FETCH_ASSOC);
//return response
print json_encode(array(
  "msg"=>"Participant credit successfully increased to " . $pass['credit']
));
flush();

//update the pass
require_once("../class/APNS.php");
$apns = new APNS();

if ($egghunt['bunniesLeft']==0) {
  //update all passes, the game is over
  $apns->updateAllPasses();
  
} else {
  //update the current pass only with the new credit
  $apns->updateForPassWithSerialNr($row['serialNr']);
}

exit();

?>