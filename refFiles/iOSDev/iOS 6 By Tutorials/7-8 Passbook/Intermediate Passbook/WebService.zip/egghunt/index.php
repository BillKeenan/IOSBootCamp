<html>
<head>
  <title>Big Easter Egg Hunt!</title>
  <meta name="viewport" 
        content="initial-scale = 0.75,maximum-scale = 0.75" />
  <style>
	form {border: 1px solid #611111; width: 380px; padding: 10px; 
         background: #ffcccc; border-radius: 15px;}
    h1 {font:italic bold 20px/30px Georgia, serif;}
    li {padding-top: 8px;}
  </style>
</head>
<body>

<form action="geteasterpass.php">
  <p>Come this Easert to the Big City Mall 
     and participate in the Easter Egg Hunt!</p>
  <ul>
    <li>Download your own unique store card now</li>
       <li>On Easter Sunday you will receive a Passbook notification on your iPhone</li>
       <li>Whoever finds first the Easter Bunny receives 25$ credit on their pass</li>
       <li>The Easter Bunny will appear in 10 different stores in the mall, so keep looking for it</li>
       <li>When the hunt is over you can spend your gained credit in the mall by showing your Easter Hunt card at the cash desk</li>
  </ul>

  <input type="submit" value="Get an Easter Egg Hunt Pass"/>
	
  </form>
</body>
</html>
