<?php
//disable browser caching for this page
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 03 Jul 1971 05:30:00 GMT");

require_once("../class/Database.php");
$db = Database::get();

//get the game state from the egghunt table
$statement = $db->prepare("SELECT * FROM egghunt");
$statement->execute();
$properties = $statement->fetch(PDO::FETCH_ASSOC);

//get the locations list
$statement = $db->prepare("SELECT * FROM locations");
$statement->execute();
$locations = $statement->fetchAll(PDO::FETCH_ASSOC);

//get the current location from  the locations table
$statement = $db->prepare("SELECT * FROM locations WHERE isBunnyHere=1");
$statement->execute();
$currentLocation = $statement->fetch(PDO::FETCH_ASSOC);
?>
<html>
<head>
  <style>
  form {border:1px solid #999; padding:10px;width:450px;
        font-family: "Myriad Pro", Arial;}
  div {color:green; font-family: "Myriad Pro", Arial;}
  </style>
  <script>
  //refresh the page so the admin can see game updates
  setTimeout("document.location.reload();", 15000);
  </script>
</head>
<body>
  <!-- show messages sent via GET -->
  <? if ($_GET['message']!="") { ?>
    <div><?=$_GET['message']?></div>
  <? } ?>
<!-- turn the game ON and OFF -->
  <? if ($properties['hasGameFinished']==0) { ?>
  <form action="setProperty.php?property=isGameOn" method="post">
    <? if ($properties['isGameOn']==1) { ?>
    <b>The Egg Hunt Game is ON</b>
    <input type="hidden" name="newValue" value="0"/>
    <input type="submit" value="Set Game to OFF"/>
    <? } else { ?>
    <b>The Egg Hunt Game is OFF</b>
    <input type="hidden" name="newValue" value="1"/>
    <input type="submit" value="Set Game to ON"/>
    <? } ?>
  </form>
  <? } ?>
<!-- show the remaining locations for the easter bunny -->
<div><?=$properties['bunniesLeft']?> locations to go.</div>
<!-- show list of locations or the current bunny location -->
<? if ($properties['isGameOn']==1 && 
       ($properties['hasGameFinished']==0)) { ?>

  <? if ($currentLocation) { ?>
  The Bunny is currently at "<?=$currentLocation['store']?>".

  <? } else { ?>
  <form action="setProperty.php?property=nextLocation" method="post">

  <select name="nextLocation">
    <? foreach ($locations as $l) { ?>
    <option value="<?=$l['IdLocation']?>">
      <?=$l['store']?>
    </option>
    <? } ?>
  </select>

  <input type="submit" value="Activate next location"/>
  </form>

  <? } ?>
  <? } ?>
</body>
</html>
