<?php
//disable browser caching for this page
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 03 Jul 1971 05:30:00 GMT");

require_once("../class/Database.php");
$db = Database::get();

//turn the game ON or OFF
if ($_GET['property']=="isGameOn") {
  $statement = $db->prepare("UPDATE egghunt SET isGameOn=?");
  $statement->execute(array((int)$_POST['newValue']));
  header("Location: index.php?message=isGameOn set to ". $_POST['newValue']."!");
  exit();
}

//set the next location the bunny can be found
if ($_GET['property']=="nextLocation") {
	//set the new bunny location
	$statement = $db->prepare("UPDATE locations SET isBunnyHere=1 WHERE IdLocation=?");
	$statement->execute(array((int)$_POST['nextLocation']));
	//set lastUpdated on all passes to now
	$db->prepare("UPDATE passes SET lastUpdated=?")->execute(array(time()));
	//send out push notifications
	require_once("../class/APNS.php");
	$apns = new APNS();
	$updatedNr = $apns->updateAllPasses();
	//send the user back to index.php 
	header("Location: index.php?message=Current Bunny location changed! Sent updates to $updatedNr passes");
	exit();
}
	
?>