CREATE DATABASE IF NOT EXISTS egghunt;
USE egghunt;

CREATE TABLE `devices` (
  `device` char(32) NOT NULL,
  `pushToken` char(64) NOT NULL,
  `serialNr` bigint(20) NOT NULL,
  PRIMARY KEY (`device`,`serialNr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `egghunt` (
  `isGameOn` smallint(6) NOT NULL DEFAULT '0',
  `hasGameFinished` smallint(6) NOT NULL DEFAULT '0',
  `bunniesLeft` smallint(6) NOT NULL DEFAULT '10'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `egghunt` VALUES   (0,0,10);

CREATE TABLE `locations` (
  `IdLocation` int(11) NOT NULL AUTO_INCREMENT,
  `store` varchar(100) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `alt` double NOT NULL,
  `isBunnyHere` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IdLocation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `locations` VALUES   (1,'CineFilm: European films',52.4819585815839,13.4333825111389,0,0);
INSERT INTO `locations` VALUES   (2,'John\'s Bike Repair',52.4818475037591,13.4327280521393,0,0);
INSERT INTO `locations` VALUES   (3,'Merry\'s Cupcake Shop',52.4820418897685,13.4308344125748,25,0);
INSERT INTO `locations` VALUES   (4,'Joe\'s Cafe',52.4824045235576,13.4325939416885,25,0);
INSERT INTO `locations` VALUES   (5,'Fish & Chips co.uk',52.4825057991268,13.4322828054428,25,0);
INSERT INTO `locations` VALUES   (6,'Icecream Princess',52.4826887479513,13.4318965673447,0,0);
INSERT INTO `locations` VALUES   (7,'Beyond store',52.481968382555,13.432502746582,0,0);
INSERT INTO `locations` VALUES   (8,'Bed and Bad',52.4821546005907,13.4329989552498,0,0);
INSERT INTO `locations` VALUES   (9,'Multicomputers',52.4822950803416,13.4326663613319,0,0);
INSERT INTO `locations` VALUES   (10,'Foodcourt area',52.4820565911965,13.4317034482956,40,0);

CREATE TABLE `passes` (
  `serialNr` bigint(20) NOT NULL,
  `authenticationToken` char(40) NOT NULL,
  `lastUpdated` int(11) NOT NULL,
  `credit` int(11) NOT NULL,
  `barcode` char(40) NOT NULL,
  `passTypeID` varchar(100) NOT NULL,
  PRIMARY KEY (`serialNr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;