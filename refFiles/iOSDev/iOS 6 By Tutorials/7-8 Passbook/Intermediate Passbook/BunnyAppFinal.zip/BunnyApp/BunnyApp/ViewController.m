//
//  ViewController.m
//  BunnyApp
//
//  Created by Fahim Farook on 17/8/12.
//  Copyright (c) 2012 RookSoft Pte. Ltd. All rights reserved.
//

#import "ViewController.h"
#import "ZBarSDK.h"
#import "AFNetworking.h"

static NSString* kBunnyAPIURL = @"http://localhost/egghunt/bunnyapi/";
static NSString* kBunnyAPISecret = @"askd873kjanf92n4ll298fkjwf923kjb235k23jb";

@interface ViewController () <ZBarReaderDelegate> {
    IBOutlet UIImageView* imgBarcode;
    IBOutlet UILabel* lblBarcodeText;
    IBOutlet UILabel* lblEndpoint;
}

@end

@implementation ViewController

-(void)viewDidLoad {
    [super viewDidLoad];
	lblEndpoint.text = kBunnyAPIURL;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnScanTapped {
	ZBarReaderViewController *reader = [[ZBarReaderViewController alloc] init];
	reader.readerDelegate = self;
	reader.supportedOrientationsMask = ZBarOrientationMaskAll;
	[self presentViewController:reader animated:YES completion:nil];
}

-(IBAction)btnSendTapped {
	NSURL *url = [NSURL URLWithString:kBunnyAPIURL];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
	[request setHTTPMethod:@"POST"];
	NSMutableDictionary* payload = [[NSMutableDictionary alloc] initWithCapacity:2];
	payload[@"barcode"] = lblBarcodeText.text;
	payload[@"token"] = kBunnyAPISecret;
	[request setHTTPBody:[NSJSONSerialization dataWithJSONObject:payload options:kNilOptions error:nil]];
	AFJSONRequestOperation *operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, NSDictionary* JSON) {
			[[[UIAlertView alloc] initWithTitle:@"Response"
										message:JSON[@"msg"]
									   delegate:nil
							  cancelButtonTitle:@"Close"
							  otherButtonTitles:nil] show];
		} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
			[[[UIAlertView alloc] initWithTitle:@"Error"
										message:[error localizedDescription]
									   delegate:nil
							  cancelButtonTitle:@"Close"
							  otherButtonTitles:nil] show];
		}];
	[operation start];
}

-(void)imagePickerController:(UIImagePickerController*)reader didFinishPickingMediaWithInfo:(NSDictionary*)info {
    //1
    id<NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    
    //2
    ZBarSymbol *symbol = nil;
    for (symbol in results)
		break;
    //3
    lblBarcodeText.text = symbol.data;
    imgBarcode.image = [info objectForKey: UIImagePickerControllerOriginalImage];
    
    //4
    [reader dismissViewControllerAnimated:YES completion:nil];
}

@end
