//
//  LikeViewController.m
//  iSocial
//
//  Created by Felipe on 9/3/12.
//  Copyright (c) 2012 Felipe Laso Marsetti. All rights reserved.
//

#import "LikeViewController.h"

@interface LikeViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@property (weak, nonatomic) IBOutlet UIButton *likeButton;

- (IBAction)likeTapped;

@end

@implementation LikeViewController

#pragma mark - IBActions

- (IBAction)likeTapped
{
}

@end
