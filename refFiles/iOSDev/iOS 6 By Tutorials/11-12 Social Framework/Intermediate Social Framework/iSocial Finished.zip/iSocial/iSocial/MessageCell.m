//
//  MessageCell.m
//  iSocial
//
//  Created by Felipe on 9/3/12.
//  Copyright (c) 2012 Felipe Laso Marsetti. All rights reserved.
//

#import "MessageCell.h"

@implementation MessageCell

@end
