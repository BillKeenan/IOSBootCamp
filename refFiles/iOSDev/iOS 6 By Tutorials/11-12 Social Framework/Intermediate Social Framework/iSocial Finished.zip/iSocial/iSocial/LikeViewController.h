//
//  LikeViewController.h
//  iSocial
//
//  Created by Felipe on 9/3/12.
//  Copyright (c) 2012 Felipe Laso Marsetti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

#define PhotoGraphURL @"https://graph.facebook.com/408881369146835/likes"
#define PhotoURL @"https://fbcdn-sphotos-e-a.akamaihd.net/hphotos-ak-prn1/s720x720/526119_408881369146835_2134350025_n.jpg"

@interface LikeViewController : UIViewController

@end
