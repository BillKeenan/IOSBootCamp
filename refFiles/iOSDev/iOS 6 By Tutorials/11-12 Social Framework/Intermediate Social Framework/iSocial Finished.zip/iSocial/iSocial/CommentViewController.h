//
//  CommentViewController.h
//  iSocial
//
//  Created by Felipe on 9/3/12.
//  Copyright (c) 2012 Felipe Laso Marsetti. All rights reserved.
//

#import <UIKit/UIKit.h>

#define CommentViewControllerIdentifier     @"CommentViewController"

@interface CommentViewController : UITableViewController

@property (strong, nonatomic) NSArray *commentsArray;

@end
