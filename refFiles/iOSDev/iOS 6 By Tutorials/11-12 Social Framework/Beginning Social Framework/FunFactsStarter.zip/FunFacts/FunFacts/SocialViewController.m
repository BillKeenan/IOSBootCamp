//
//  ViewController.m
//  FunFacts
//
//  Created by Ray Wenderlich on 8/13/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "SocialViewController.h"

#define AuthorFactsKey      @"facts"
#define AuthorImageKey      @"image"
#define AuthorNameKey       @"name"
#define AuthorTwitterKey    @"twitter"

@interface SocialViewController ()

@property (weak, nonatomic) IBOutlet UIButton *actionButton;
@property (weak, nonatomic) IBOutlet UIView *authorBackgroundView;
@property (weak, nonatomic) IBOutlet UIImageView *authorImageView;
@property (weak, nonatomic) IBOutlet UIButton *facebookButton;
@property (weak, nonatomic) IBOutlet UITextView *factTextView;
@property (weak, nonatomic) IBOutlet UILabel *factTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIButton *twitterButton;
@property (weak, nonatomic) IBOutlet UILabel *twitterLabel;
@property (weak, nonatomic) IBOutlet UIButton *weiboButton;
//foo
@property (strong, nonatomic) NSArray *authorsArray;

- (IBAction)actionTapped;
- (IBAction)socialTapped:(id)sender;

@end

@implementation SocialViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)actionTapped
{
    
}

- (IBAction)socialTapped:(id)sender
{
    
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [self becomeFirstResponder];
}

- (NSArray *)authorsArray
{
    if (!_authorsArray)
    {
        NSString *authorsArrayPath = [[NSBundle mainBundle]
                                      pathForResource:@"FactsList" ofType:@"plist"];
        self.authorsArray = [NSArray
                             arrayWithContentsOfFile:authorsArrayPath];
    }
    
    return _authorsArray;
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    if (motion == UIEventSubtypeMotionShake)
    {
        NSUInteger authorRandSize = self.authorsArray.count;
        NSUInteger authorRandomIndex = (arc4random() % ((unsigned)authorRandSize));

        NSDictionary *authorDictionary = self.authorsArray[authorRandomIndex];

        NSArray *facts = authorDictionary[AuthorFactsKey];
        NSString *image = authorDictionary[AuthorImageKey];
        NSString *name = authorDictionary[AuthorNameKey];
        NSString *twitter = authorDictionary[AuthorTwitterKey];

        NSUInteger factsRandSize = facts.count;
        NSUInteger factsRandomIndex = (arc4random() % ((unsigned)factsRandSize));

        self.factTitleLabel.hidden = NO;

        self.factTextView.text = facts[factsRandomIndex];
        self.nameLabel.text = name;
        self.twitterLabel.text = twitter;
        self.authorImageView.image = [UIImage imageNamed:image];
    }
}


@end
