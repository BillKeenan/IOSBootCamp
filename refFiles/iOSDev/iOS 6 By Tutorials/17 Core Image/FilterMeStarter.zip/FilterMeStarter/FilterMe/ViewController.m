//
//  ViewController.m
//  FilterMe
//
//  Created by Jake Gundersen on 7/11/12.
//  Copyright (c) 2012 Jake Gundersen. All rights reserved.

//  Some of the AVAssetWriter code was adapted from the GPUImage project.

#import "ViewController.h"


@interface ViewController () 
    



@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
   
}



@end
