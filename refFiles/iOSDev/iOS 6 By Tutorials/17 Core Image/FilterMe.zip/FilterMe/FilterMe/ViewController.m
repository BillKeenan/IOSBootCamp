//
//  ViewController.m
//  FilterMe
//
//  Created by Jake Gundersen on 7/11/12.
//  Copyright (c) 2012 Jake Gundersen. All rights reserved.

//  Some of the AVAssetWriter code was adapted from the brillian GPUImage project.

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <GLKit/GLKit.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "CZGPerlinGenerator.h"

@interface ViewController () <AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate, AVCaptureMetadataOutputObjectsDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate> {
    
    AVCaptureSession *_session;
    
    CIContext *_coreImageContext;
    EAGLContext *_context;
    
    IBOutlet GLKView *_glView;

    IBOutlet UISegmentedControl *_filterSegment;

    CZGPerlinGenerator *_perlin;
    
    NSArray *faces;
    
    AVAssetWriter *_assetWriter;
    AVAssetWriterInput *_assetWriterAudioInput;
    AVAssetWriterInputPixelBufferAdaptor *_assetWriterPixelBufferInput;
    BOOL _isWriting;
    CMTime currentSampleTime;
    
    UIPopoverController *_poController;
}

- (IBAction)record:(id)sender;
- (IBAction)pickVideo:(id)sender;




@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    
    if (!_context) {
        NSLog(@"Failed to create ES context");
    }
   
    _glView.context = _context;
    
    float screenWidth = [[UIScreen mainScreen] bounds].size.height;
    _glView.contentScaleFactor = 640.0 / screenWidth;
    
    _coreImageContext = [CIContext contextWithEAGLContext:_context];
    
    _session = [[AVCaptureSession alloc] init]; //1
    [_session beginConfiguration]; //2
    
    if([_session canSetSessionPreset:AVCaptureSessionPreset640x480]) {
        [_session setSessionPreset:AVCaptureSessionPreset640x480];
        
    } //3
    
    NSArray *devices = [AVCaptureDevice devices]; //4
    AVCaptureDevice *videoDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];  //5
    
    
    for (AVCaptureDevice *d in devices) {
        if (d.position == AVCaptureDevicePositionFront && [d hasMediaType:AVMediaTypeVideo]) {
            videoDevice = d;
        }
        NSLog(@"device %@", d);
    } //6 
    
    
    NSError *err;
    AVCaptureDeviceInput *videoInput = [AVCaptureDeviceInput deviceInputWithDevice:videoDevice error:&err];
    [_session addInput:videoInput];  //7
    
    if (err) {
        NSLog(@"video device input %@", err.localizedDescription);
    }
    
    AVCaptureDevice *mic = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
    AVCaptureDeviceInput *audioDeviceInput = [AVCaptureDeviceInput deviceInputWithDevice:mic error:&err];
    
    if (err) {
        NSLog(@"Video Device Error %@", [err localizedDescription]);
    }
    
    [_session addInput:audioDeviceInput];
    
    AVCaptureAudioDataOutput *audioOutput = [[AVCaptureAudioDataOutput alloc] init];
    
    [audioOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
    
    [_session addOutput:audioOutput];
    
    AVCaptureVideoDataOutput *videoOutput = [[AVCaptureVideoDataOutput alloc] init]; //8
    
    [videoOutput setAlwaysDiscardsLateVideoFrames:YES];  //9
    [videoOutput setVideoSettings:@{(id)kCVPixelBufferPixelFormatTypeKey : @(kCVPixelFormatType_32BGRA)}]; //10
    
    [videoOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()]; //11
    
    [_session addOutput:videoOutput];
    
    AVCaptureMetadataOutput *metaDataOutput = [[AVCaptureMetadataOutput alloc] init];
    [metaDataOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    [_session addOutput:metaDataOutput];
    
    [_session commitConfiguration];
    [_session startRunning]; //11
    
    _perlin = [CZGPerlinGenerator perlinGenerator];
    _perlin.zoom = 100;
  
    _isWriting = NO;
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    
    NSString *outputClass = NSStringFromClass([captureOutput class]);
    if ([outputClass isEqualToString:@"AVCaptureAudioDataOutput"]) {
        if (_isWriting && _assetWriterAudioInput.isReadyForMoreMediaData) {
            BOOL succ = [_assetWriterAudioInput appendSampleBuffer:sampleBuffer];
            if (!succ) {
                NSLog(@"audio buffer not appended");
            }
        }
        
    } else {
        
        CVPixelBufferRef pixelBuffer = (CVPixelBufferRef)CMSampleBufferGetImageBuffer(sampleBuffer);
        
        CIImage *image = [CIImage imageWithCVPixelBuffer:pixelBuffer];
        
        
        if (self.interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            image = [image imageByApplyingTransform:CGAffineTransformMakeRotation(M_PI)];
            image = [image imageByApplyingTransform:CGAffineTransformMakeTranslation(640.0, 480.0)];
        }
                
        switch (_filterSegment.selectedSegmentIndex) {
            case 0:
                image = [self simpleEdgeDetection:image];
                break;
            case 1:
                image = [self oldTimey:image];
                break;
            case 2:
                image = [self makeFaces:image];
                break;
            case 3:
                image = [self kaleidoscope:image];
                break;
            case 4:
                image = [self bloom:image];
                break;
            default:
                break;
        }
        
        
        currentSampleTime = CMSampleBufferGetOutputPresentationTimeStamp(sampleBuffer);
        
        if (_isWriting && _assetWriterPixelBufferInput.assetWriterInput.isReadyForMoreMediaData) {
            
            CVPixelBufferRef newPixelBuffer = NULL;////
            
            CVPixelBufferPoolCreatePixelBuffer(NULL, [_assetWriterPixelBufferInput pixelBufferPool], &newPixelBuffer);////
            
            [_coreImageContext render:image toCVPixelBuffer:newPixelBuffer bounds:CGRectMake(0, 0, 640, 480) colorSpace:NULL];
            
            BOOL success = [_assetWriterPixelBufferInput appendPixelBuffer:newPixelBuffer withPresentationTime:currentSampleTime];
            
            if (!success) {
                NSLog(@"Pixel Buffer not appended");
            }
            CVPixelBufferRelease(newPixelBuffer);////
        }
        
        [_coreImageContext drawImage:image inRect:[image extent] fromRect:[image extent]];
        
        [_context presentRenderbuffer:GL_RENDERBUFFER ];
    }
}

-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    
    NSMutableArray *newAr = [NSMutableArray array];
    for (AVMetadataFaceObject *fo in metadataObjects) {
        CGPoint center = CGPointMake(fo.bounds.origin.x + fo.bounds.size.width/2, fo.bounds.origin.y + fo.bounds.size.height / 2);
        float width = fo.bounds.size.width;
        NSDictionary *d = @{    @"position" : [NSValue valueWithCGPoint:center],
                                @"size" : @(width)
        };
        [newAr addObject:d];
    }
    faces = (NSArray *)newAr;
}

-(CIImage *)bloom:(CIImage *)inputImage {
    CIFilter *bloom = [CIFilter filterWithName:@"CIBloom"];
    [bloom setValue:inputImage forKey:kCIInputImageKey];
    [bloom setValue:@30 forKey:@"inputRadius"];
    [bloom setValue:@1.0f forKey:@"inputIntensity"];
    return bloom.outputImage;
}

-(CIImage *)kaleidoscope:(CIImage *)inputImage {
    CIFilter *kaleid = [CIFilter filterWithName:@"CISixfoldRotatedTile"];
    [kaleid setValue:inputImage forKey:kCIInputImageKey];
    
    [kaleid setValue:[CIVector vectorWithCGPoint:CGPointMake(320, 240)] forKey:@"inputCenter"];
    [kaleid setValue:@200 forKey:@"inputWidth"];
    
    CFAbsoluteTime timeNow = CFAbsoluteTimeGetCurrent();
    timeNow = (fmodl(timeNow, 4 * 6.28) / 4.0 )- 3.14;
    
    [kaleid setValue:@(timeNow) forKey:@"inputAngle"];
    
    CIFilter *crop = [CIFilter filterWithName:@"CICrop"];
    [crop setValue:kaleid.outputImage forKey:kCIInputImageKey];
    [crop setValue:[CIVector vectorWithCGRect:[inputImage extent]] forKey:@"inputRectangle"];
    
    return crop.outputImage;
}

-(CIImage *)simpleEdgeDetection:(CIImage *)inputImage {
 
    
    CIFilter *desaturate = [CIFilter filterWithName:@"CIColorControls"];
    [desaturate setValue:inputImage forKey:kCIInputImageKey];
    [desaturate setValue:@0.0f forKey:@"inputSaturation"];
    
    CIFilter *blur = [CIFilter filterWithName:@"CIGaussianBlur"];
    [blur setValue:desaturate.outputImage forKey:kCIInputImageKey];
    [blur setValue:@3.0f forKey:@"inputRadius"];
    
    CIFilter *inverted = [CIFilter filterWithName:@"CIColorInvert"];
    [inverted setValue:blur.outputImage forKey:kCIInputImageKey];
    
    CIFilter *blendDodge = [CIFilter filterWithName:@"CIColorDodgeBlendMode"];
    [blendDodge setValue:inverted.outputImage forKey:kCIInputBackgroundImageKey];
    [blendDodge setValue:desaturate.outputImage forKey:kCIInputImageKey];
    
    CIFilter *invert2 = [CIFilter filterWithName:@"CIColorInvert"];
    [invert2 setValue:blendDodge.outputImage forKey:kCIInputImageKey];
    
    
    CIFilter *blendBurn = [CIFilter filterWithName:@"CIColorDodgeBlendMode"];
    [blendBurn setValue:blendDodge.outputImage forKey:kCIInputImageKey];
    [blendBurn setValue:inputImage forKey:kCIInputBackgroundImageKey];
    
    return blendBurn.outputImage;

}

-(CIImage *)oldTimey:(CIImage *)inputImage {
    CFAbsoluteTime timeNow = CFAbsoluteTimeGetCurrent();
    
    float first = [_perlin perlinNoiseX:cos(timeNow) * 1000.0 y:10.0 z:10.0 t:10.0];
    float second = [_perlin perlinNoiseX:cos(timeNow) * 1000.0 y:105.0 z:10.0 t:10.0];
    float third = [_perlin perlinNoiseX:sin(timeNow) * 1000.0 y:200.0 z:10.0 t:10.0];
    
    CIFilter *blackandwhite = [CIFilter filterWithName:@"CIColorControls"];
    [blackandwhite setValue:@0.1f forKey:@"inputSaturation"];
    [blackandwhite setValue:@(first * 0.05) forKey:@"inputBrightness"];
    [blackandwhite setValue:inputImage forKey:kCIInputImageKey];
    
    CIFilter *vignette = [CIFilter filterWithName:@"CIVignette"];
    [vignette setValue:blackandwhite.outputImage forKey:kCIInputImageKey];
    [vignette setValue:@10 forKey:@"inputRadius"];
    [vignette setValue:@(third + 2) forKey:@"inputIntensity"];

    CGAffineTransform transForm = CGAffineTransformMakeTranslation(first * 1.0, 1.0 + (second * 10)); ////
    CIImage *returnImage = [vignette.outputImage imageByApplyingTransform:transForm];
    
    return returnImage;

}

-(CIImage *)makeFaces:(CIImage *)inputImage {
    CIFilter *filter;
    
    for (NSDictionary *f in faces) {
        CIFilter *distortionFilter = [CIFilter filterWithName:@"CIPinchDistortion"];
        int indx = [faces indexOfObject:f];
        if (indx == 0) {
            [distortionFilter setValue:inputImage forKey:kCIInputImageKey];
        } else {
            [distortionFilter setValue:filter.outputImage forKey:kCIInputImageKey];
        }
        CGPoint center = [[f objectForKey:@"position"] CGPointValue];
        center = CGPointMake(640.0 * center.x, 480.0 - 480.0 * center.y);
        float size = [[f objectForKey:@"size"] floatValue] * 640.0 / 2;
        if (self.interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            center = CGPointMake(640 - center.x , 480 - center.y);
        }
        [distortionFilter setValue:@(size) forKey:@"inputRadius"];
        [distortionFilter setValue:[CIVector vectorWithCGPoint:center] forKey:@"inputCenter"];
        [distortionFilter setValue:@0.80 forKey:@"inputScale"];
        
        filter = distortionFilter;
        
    }
    
    CIImage *returnImage;
    if (filter) {
        returnImage = filter.outputImage;
    } else {
        returnImage = inputImage;
    }
    
    return [returnImage imageByCroppingToRect:[inputImage extent]];
}

-(NSURL *)movieURL {
    NSString *tempDir = NSTemporaryDirectory();
    NSString *urlString = [tempDir stringByAppendingPathComponent:@"tmpMov.mov"];
    return [NSURL fileURLWithPath:urlString];
}

-(void)checkForAndDeleteFile {
    
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL exist = [fm fileExistsAtPath:[self movieURL].absoluteString];
    NSError *err;
    if (exist) {
        [fm removeItemAtURL:[self movieURL] error:&err];
        NSLog(@"file deleted");
        if (err) {
            NSLog(@"file remove error, %@", err.localizedDescription );
        }
        
    } else {
        NSLog(@"no file by that name");
    }
}

-(void)createWriter {
    //My setup code is based heavily on the GPUImage project, https://github.com/BradLarson/GPUImage so some of these dictionary names and structure are similar to the code from that project - I recommend you check it out if you are interested in Video filtering/recording
    [self checkForAndDeleteFile];
    
    NSError *error;
    _assetWriter = [[AVAssetWriter alloc] initWithURL:[self movieURL] fileType:AVFileTypeQuickTimeMovie error:&error];
    
    if (error) {
        NSLog(@"Couldn't create writer, %@", error.localizedDescription);
        return;
    }
    
    NSDictionary *outputSettings = @{
    AVVideoCodecKey : AVVideoCodecH264,
    AVVideoWidthKey : @640,
    AVVideoHeightKey : @480
    };
    
    AVAssetWriterInput *assetWriterVideoInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeVideo outputSettings:outputSettings];
    
    assetWriterVideoInput.expectsMediaDataInRealTime = YES;
    
    NSDictionary *sourcePixelBufferAttributesDictionary = @{(id)kCVPixelBufferPixelFormatTypeKey: @(kCVPixelFormatType_32BGRA),
    (id)kCVPixelBufferWidthKey: @640,
    (id)kCVPixelBufferHeightKey: @480};
    
    _assetWriterPixelBufferInput = [AVAssetWriterInputPixelBufferAdaptor assetWriterInputPixelBufferAdaptorWithAssetWriterInput:assetWriterVideoInput sourcePixelBufferAttributes:sourcePixelBufferAttributesDictionary];
    
    if ([_assetWriter canAddInput:assetWriterVideoInput]) {
        [_assetWriter addInput:assetWriterVideoInput];
    } else {
        NSLog(@"can't add video writer input %@", assetWriterVideoInput);
    }
    
    _assetWriterAudioInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeAudio outputSettings:nil];
    if ([_assetWriter canAddInput:_assetWriterAudioInput]) {
        [_assetWriter addInput:_assetWriterAudioInput];
        _assetWriterAudioInput.expectsMediaDataInRealTime = YES;
    }
}

- (IBAction)record:(id)sender {
    UIBarButtonItem *button = (UIBarButtonItem *)sender;
    if (!_isWriting) {
        [self createWriter];
        _isWriting = YES;
        button.title = @"Stop";
        [_assetWriter startWriting];
        [_assetWriter startSessionAtSourceTime:currentSampleTime];
        
    } else {
        _isWriting = NO;
        button.title = @"Record";
        [_assetWriter finishWriting];
        [self saveMovieToCameraRoll];
    }
}


//
- (IBAction)pickVideo:(id)sender {
    if (_isWriting) {
        return;
    }
    [_session stopRunning];
    if (_poController.isPopoverVisible) {
        [_poController dismissPopoverAnimated:YES];
    } else {
        if ([UIImagePickerController isSourceTypeAvailable:
             UIImagePickerControllerSourceTypeSavedPhotosAlbum])
        {
            UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
            imagePicker.delegate = self;
            imagePicker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
            imagePicker.mediaTypes = @[(NSString *) kUTTypeMovie];
            imagePicker.allowsEditing = YES;
            
            if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
                _poController = [[UIPopoverController alloc]
                                 initWithContentViewController:imagePicker];
                
                _poController.delegate = self;
                
                [_poController
                 presentPopoverFromBarButtonItem:sender
                 permittedArrowDirections:UIPopoverArrowDirectionUp
                 animated:YES];
            } else {
                [self presentViewController:imagePicker animated:YES completion:^{
                    [_session startRunning];
                }];
            }
        }
    }
}

-(void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    [_session startRunning];
    NSLog(@"session restart");
}



- (void)saveMovieToCameraRoll
{
    
	ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
	[library writeVideoAtPathToSavedPhotosAlbum:[self movieURL]
								completionBlock:^(NSURL *assetURL, NSError *error) {
									if (error) {
                                        NSLog(@"Error %@", [error localizedDescription]);
                                    } else {
                                        [self checkForAndDeleteFile];
                                        NSLog(@"finished saving");
                                    }
								}];
}



@end
