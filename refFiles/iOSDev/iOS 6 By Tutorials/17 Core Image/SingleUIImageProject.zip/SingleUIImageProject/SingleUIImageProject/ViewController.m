//
//  ViewController.m
//  SingleUIImageProject
//
//  Created by Jake Gundersen on 7/9/12.
//  Copyright (c) 2012 Jake Gundersen. All rights reserved.
//

#import "ViewController.h"


@interface ViewController () {
    CIImage *_image;
    EAGLContext *_context;
    CIContext *_coreImageContext;
    CIFilter *_sepiaFilter;
}

@property (strong, nonatomic) IBOutlet UIImageView *imgView;
- (IBAction)changeSlider:(id)sender;

@end

@implementation ViewController
@synthesize imgView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSArray *ciFilters = [CIFilter filterNamesInCategory:kCICategoryBuiltIn];
    for (NSString *filter in ciFilters) {
        NSLog(@"filter name %@", filter);
        NSLog(@"filter %@", [[CIFilter filterWithName:filter] attributes]);
    }
    
    _context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    if (!_context) {
        NSLog(@"No EAGL Context created");
    }

    
    
    _coreImageContext = [CIContext contextWithEAGLContext:_context];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"hubble" ofType:@"png"];
    NSURL *fileURL = [NSURL fileURLWithPath:path];
    _image = [CIImage imageWithContentsOfURL:fileURL];
    
    _sepiaFilter = [CIFilter filterWithName:@"CISepiaTone"];
    [_sepiaFilter setValue:_image forKey:kCIInputImageKey];
    [_sepiaFilter setValue:[NSNumber numberWithFloat:1.0] forKey:@"inputIntensity"];
    
    CGImageRef cgImg = [_coreImageContext createCGImage:_sepiaFilter.outputImage fromRect:[_sepiaFilter.outputImage extent]];
    UIImage *uiImage = [UIImage imageWithCGImage:cgImg];
    imgView.image = uiImage;
    CGImageRelease(cgImg);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)changeSlider:(id)sender {
    UISlider *slide = (UISlider *)sender;
    
    [_sepiaFilter setValue:[NSNumber numberWithFloat:slide.value] forKey:@"inputIntensity"];
    
    CGImageRef cgImg = [_coreImageContext createCGImage:_sepiaFilter.outputImage fromRect:[_sepiaFilter.outputImage extent]];
    UIImage *uiImage = [UIImage imageWithCGImage:cgImg];
    imgView.image = uiImage;
    CGImageRelease(cgImg);
    
}
@end
