//
//  main.m
//  FunFacts
//
//  Created by Felipe on 7/15/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
