//
//  SocialViewController.m
//  FunFacts
//
//  Created by Felipe on 7/15/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import "FunActivity.h"
#import "SocialViewController.h"
#import <QuartzCore/QuartzCore.h>

#define AuthorFactsKey      @"facts"
#define AuthorImageKey      @"image"
#define AuthorNameKey       @"name"
#define AuthorTwitterKey    @"twitter"

typedef enum SocialButtonTags
{
    SocialButtonTagFacebook,
    SocialButtonTagSinaWeibo,
    SocialButtonTagTwitter
} SocialButtonTags;

@interface SocialViewController ()

@property (weak, nonatomic) IBOutlet UIButton *actionButton;
@property (weak, nonatomic) IBOutlet UIView *authorBackgroundView;
@property (weak, nonatomic) IBOutlet UIImageView *authorImageView;
@property (strong, nonatomic) NSArray *authorsArray;
@property (assign, nonatomic) BOOL deviceWasShaken;
@property (weak, nonatomic) IBOutlet UIButton *facebookButton;
@property (weak, nonatomic) IBOutlet UITextView *factTextView;
@property (weak, nonatomic) IBOutlet UILabel *factTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIButton *twitterButton;
@property (weak, nonatomic) IBOutlet UILabel *twitterLabel;
@property (weak, nonatomic) IBOutlet UIButton *weiboButton;

- (IBAction)actionTapped;
- (void)generateRandomFact;
- (void)showUnavailableAlertForServiceType:(NSString *)serviceType;
- (IBAction)socialTapped:(id)sender;

@end

@implementation SocialViewController

#pragma mark - Events

- (BOOL)accessibilityPerformMagicTap
{
    [self generateRandomFact];
    
    return YES;
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    if (motion == UIEventSubtypeMotionShake)
    {
        self.deviceWasShaken = YES;
        
        [self generateRandomFact];
    }
}

#pragma mark - IBActions

- (IBAction)actionTapped
{
    if (self.deviceWasShaken)
    {
        FunActivity *funActivity = [[FunActivity alloc] init];
        
        NSString *initalTextString = [NSString stringWithFormat:@"Fun Fact: %@", self.factTextView.text];
        UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:@[self.authorImageView.image, initalTextString] applicationActivities:@[funActivity]];
        [self presentViewController:activityViewController animated:YES completion:nil];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Shake"
                                                            message:@"Before you can share, please shake the device in order to get a random Fun Fact"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Dismiss"
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}

- (IBAction)socialTapped:(id)sender
{    
    if (self.deviceWasShaken)
    {
        NSString *serviceType = @"";
        
        switch (((UIButton *)sender).tag)
        {
            case SocialButtonTagFacebook:
                serviceType = SLServiceTypeFacebook;
                break;
            
            case SocialButtonTagSinaWeibo:
                serviceType = SLServiceTypeSinaWeibo;
                break;
                
            case SocialButtonTagTwitter:
                serviceType = SLServiceTypeTwitter;
                break;
                
            default:
                break;
        }
            
        if (![SLComposeViewController isAvailableForServiceType:serviceType])
        {
            [self showUnavailableAlertForServiceType:serviceType];
        }
        else
        {
            SLComposeViewController *composeViewController = [SLComposeViewController composeViewControllerForServiceType:serviceType];
            [composeViewController addImage:self.authorImageView.image];
            NSString *initalTextString = [NSString stringWithFormat:@"Fun Fact: %@", self.factTextView.text];
            [composeViewController setInitialText:initalTextString];
            [self presentViewController:composeViewController animated:YES completion:nil];
        }
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Shake"
                                                            message:@"Before you can share, please shake the device in order to get a random Fun Fact"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Dismiss"
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}

#pragma mark - Private Methods

- (void)generateRandomFact
{
    NSUInteger authorRandSize = self.authorsArray.count;
    NSUInteger authorRandomIndex = (arc4random() % ((unsigned)authorRandSize));
    
    NSDictionary *authorDictionary = self.authorsArray[authorRandomIndex];
    
    NSArray *facts = authorDictionary[AuthorFactsKey];
    NSString *image = authorDictionary[AuthorImageKey];
    NSString *name = authorDictionary[AuthorNameKey];
    NSString *twitter = authorDictionary[AuthorTwitterKey];
    
    NSUInteger factsRandSize = facts.count;
    NSUInteger factsRandomIndex = (arc4random() % ((unsigned)factsRandSize));
        
    self.authorImageView.image = [UIImage imageNamed:image];
    self.authorImageView.accessibilityLabel = name;
    
    self.factTextView.text = facts[factsRandomIndex];
    
    self.factTitleLabel.hidden = NO;
    self.factTitleLabel.accessibilityLabel = [NSString stringWithFormat:@"%@: %@", self.factTitleLabel.text, name];
    
    self.nameLabel.text = name;
    self.nameLabel.isAccessibilityElement = YES;
    self.nameLabel.accessibilityLabel = [NSString stringWithFormat:@"Author Name: %@", name];
    
    self.twitterLabel.text = twitter;
    self.twitterLabel.isAccessibilityElement = YES;
    self.twitterLabel.accessibilityLabel = [NSString stringWithFormat:@"Twitter Username: %@", twitter];
    
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.factTextView);
}

- (void)showUnavailableAlertForServiceType:(NSString *)serviceType
{
    NSString *serviceName = @"";
    
    if (serviceType == SLServiceTypeFacebook)
    {
        serviceName = @"Facebook";
    }
    else if (serviceType == SLServiceTypeSinaWeibo)
    {
        serviceName = @"Sina Weibo";
    }
    else if (serviceType == SLServiceTypeTwitter)
    {
        serviceName = @"Twitter";
    }
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Account"
                                                        message:[NSString stringWithFormat:@"Please go to the device settings and add a %@ account in order to share through that service", serviceName]
                                                       delegate:nil
                                              cancelButtonTitle:@"Dismiss"
                                              otherButtonTitles:nil];
    [alertView show];
}

#pragma mark - Properties

- (NSArray *)authorsArray
{
    if (!_authorsArray)
    {
        NSString *authorsArrayPath = [[NSBundle mainBundle] pathForResource:@"FactsList" ofType:@"plist"];
        self.authorsArray = [NSArray arrayWithContentsOfFile:authorsArrayPath];
    }
    
    return _authorsArray;
}

#pragma mark - View Lifecycle

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)didReceiveMemoryWarning
{
    if ([self.view window] == nil)
    {
        _authorImageView = nil;
        _authorsArray = nil;
        _factTextView = nil;
        _nameLabel = nil;
        _twitterLabel = nil;
        
        self.view = nil;
    }
}

- (NSUInteger)supportedInterfaceOrientations
{
    return  UIInterfaceOrientationMaskPortrait;
}

- (void)viewDidAppear:(BOOL)animated
{
    [self becomeFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.authorBackgroundView.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(10.0f, 10.0f)];
    //[[UIColor blackColor] setFill];
    
    self.authorBackgroundView.layer.borderWidth = 1.0f;
    self.authorBackgroundView.layer.borderColor = [[UIColor colorWithWhite:0.2 alpha:1.0] CGColor];
    self.authorBackgroundView.layer.cornerRadius = 10.0f;
    self.authorBackgroundView.layer.masksToBounds = YES;
    
    self.authorImageView.clipsToBounds = YES;
    self.authorImageView.contentMode = UIViewContentModeScaleAspectFit;
    self.authorImageView.layer.borderWidth = 1.0f;
    self.authorImageView.layer.borderColor = [[UIColor colorWithWhite:0.2 alpha:1.0] CGColor];
    self.authorImageView.layer.shadowColor = [[UIColor colorWithWhite:0.75 alpha:1.0] CGColor];
    self.authorImageView.layer.shadowOffset = CGSizeMake(-1.0f, -1.0f);
    self.authorImageView.layer.shadowOpacity = 0.5f;
        
    self.factTextView.text = @"Shake to get a Fun Fact from one of our Authors";
    self.factTextView.layer.borderWidth = 1.0f;
    self.factTextView.layer.borderColor = [[UIColor colorWithWhite:0.2 alpha:1.0] CGColor];
    self.factTextView.layer.cornerRadius = 10.0f;
    self.factTextView.layer.masksToBounds = YES;
    self.factTextView.layer.shadowColor = [[UIColor colorWithWhite:0.75 alpha:1.0] CGColor];
    self.factTextView.layer.shadowOffset = CGSizeMake(-1.0f, -1.0f);
    self.factTextView.layer.shadowOpacity = 0.5f;
    
    self.factTitleLabel.hidden = YES;
    
    self.nameLabel.text = self.twitterLabel.text = @"";
    
    [self.actionButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] forState:UIControlStateNormal];
    [self.facebookButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] forState:UIControlStateNormal];
    [self.twitterButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] forState:UIControlStateNormal];
    [self.weiboButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] forState:UIControlStateNormal];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
}

@end
