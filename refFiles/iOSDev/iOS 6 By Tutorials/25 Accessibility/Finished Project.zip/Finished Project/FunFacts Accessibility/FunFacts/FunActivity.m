//
//  FunActivity.m
//  FunFacts
//
//  Created by Felipe on 7/15/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

#import "FunActivity.h"
#import <QuartzCore/QuartzCore.h>

@interface FunActivity ()

@property (strong, nonatomic) UIImage *authorImage;
@property (strong, nonatomic) NSString *funFactText;

@end

@implementation FunActivity

- (UIImage *)activityImage
{
    return [UIImage imageNamed:@"activity.png" ];
}

- (NSString *)activityTitle
{
    return @"Save Quote To Photos";
}

- (NSString *)activityType
{
    return @"li.iFe.FunFacts.quoteView";
}

- (BOOL)canPerformWithActivityItems:(NSArray *)activityItems
{
    for (int i = 0; i < activityItems.count; i++)
    {
        id item = activityItems[i];
             
        if ([item class] == [UIImage class] || [item isKindOfClass:[NSString class]])
        {
            
        }
        else
        {
            return NO;
        }
    }
    
    return YES;
}

- (void)performActivity
{    
    CGSize quoteSize = CGSizeMake(640, 960);
    UIGraphicsBeginImageContext(quoteSize);
    
    UIView *quoteView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, quoteSize.width, quoteSize.height)];
    quoteView.backgroundColor = [UIColor blackColor];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:self.authorImage];
    imageView.frame = CGRectMake(20, 20, 600, 320);
    imageView.backgroundColor = [UIColor clearColor];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [quoteView addSubview:imageView];
    
    UILabel *factLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 360, 600, 600)];
    factLabel.backgroundColor = [UIColor clearColor];
    factLabel.numberOfLines = 10;
    factLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:44];
    factLabel.textColor = [UIColor whiteColor];
    factLabel.text = self.funFactText;
    factLabel.textAlignment = NSTextAlignmentCenter;
    
    NSLog(@"%@", factLabel.text);
    
    [quoteView addSubview:factLabel];
    
    [quoteView.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *imageToSave = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    UIImageWriteToSavedPhotosAlbum(imageToSave, nil, nil, nil);
}

- (void)prepareWithActivityItems:(NSArray *)activityItems
{
    for (int i = 0; i < activityItems.count; i++)
    {
        id item = activityItems[i];
        
        if ([item class] == [UIImage class])
        {
            self.authorImage = item;
        }
        else if ([item isKindOfClass:[NSString class]])
        {
            self.funFactText = item;
        }
    }
}

@end
