//
//  SocialViewController.h
//  FunFacts
//
//  Created by Felipe on 7/15/12.
//  Copyright (c) 2012 Felipe. All rights reserved.
//

@interface SocialViewController : UIViewController

@end
