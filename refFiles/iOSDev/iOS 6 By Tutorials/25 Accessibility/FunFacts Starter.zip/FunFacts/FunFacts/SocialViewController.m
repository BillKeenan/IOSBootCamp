//
//  ViewController.m
//  FunFacts
//
//  Created by Ray Wenderlich on 8/13/12.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import "SocialViewController.h"
#import "FunActivity.h"
// foo
#import <QuartzCore/QuartzCore.h>

#define AuthorFactsKey      @"facts"
#define AuthorImageKey      @"image"
#define AuthorNameKey       @"name"
#define AuthorTwitterKey    @"twitter"

typedef enum SocialButtonTags
{
    SocialButtonTagFacebook,
    SocialButtonTagSinaWeibo,
    SocialButtonTagTwitter
} SocialButtonTags;

@interface SocialViewController ()

@property (weak, nonatomic) IBOutlet UIButton *actionButton;
@property (weak, nonatomic) IBOutlet UIView *authorBackgroundView;
@property (weak, nonatomic) IBOutlet UIImageView *authorImageView;
@property (weak, nonatomic) IBOutlet UIButton *facebookButton;
@property (weak, nonatomic) IBOutlet UITextView *factTextView;
@property (weak, nonatomic) IBOutlet UILabel *factTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIButton *twitterButton;
@property (weak, nonatomic) IBOutlet UILabel *twitterLabel;
@property (weak, nonatomic) IBOutlet UIButton *weiboButton;
@property (strong, nonatomic) NSArray *authorsArray;
//foo
@property (assign, nonatomic) BOOL deviceWasShaken;

- (IBAction)actionTapped;
- (IBAction)socialTapped:(id)sender;

@end

@implementation SocialViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.authorBackgroundView.layer.borderWidth = 1.0f;
    self.authorBackgroundView.layer.borderColor = [[UIColor
                                                    colorWithWhite:0.2 alpha:1.0] CGColor];
    self.authorBackgroundView.layer.cornerRadius = 10.0f;
    self.authorBackgroundView.layer.masksToBounds = YES;
    
    self.authorImageView.contentMode =
    UIViewContentModeScaleAspectFit;
    self.authorImageView.image = [UIImage
                                  imageNamed:@"funfacts.png"];
    self.authorImageView.layer.borderWidth = 1.0f;
    self.authorImageView.layer.borderColor = [[UIColor
                                               colorWithWhite:0.2 alpha:1.0] CGColor];
    self.authorImageView.layer.shadowColor = [[UIColor
                                               colorWithWhite:0.75 alpha:1.0] CGColor];
    self.authorImageView.layer.shadowOffset =
    CGSizeMake(-1.0f, -1.0f);
    self.authorImageView.layer.shadowOpacity = 0.5f;
    
    self.factTextView.text = @"Shake to get a Fun Fact from a random iOS 6 By Tutorials author or editor! ";
    self.factTextView.layer.borderWidth = 1.0f;
    self.factTextView.layer.borderColor = [[UIColor
                                            colorWithWhite:0.2 alpha:1.0] CGColor];
    self.factTextView.layer.cornerRadius = 10.0f;
    self.factTextView.layer.masksToBounds = YES;
    self.factTextView.layer.shadowColor = [[UIColor
                                            colorWithWhite:0.75 alpha:1.0] CGColor];
    self.factTextView.layer.shadowOffset =
    CGSizeMake(-1.0f, -1.0f);
    self.factTextView.layer.shadowOpacity = 0.5f;
    
    self.factTitleLabel.hidden = YES;
    
    self.nameLabel.text = self.twitterLabel.text = @"";
    
    [self.actionButton setBackgroundImage:[[UIImage
                                            imageNamed:@"button.png"]
                                           resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)]
                                 forState:UIControlStateNormal];
    [self.facebookButton setBackgroundImage:[[UIImage
                                              imageNamed:@"button.png"]
                                             resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)]
                                   forState:UIControlStateNormal];
    [self.twitterButton setBackgroundImage:[[UIImage
                                             imageNamed:@"button.png"] 
                                            resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] 
                                  forState:UIControlStateNormal];
    [self.weiboButton setBackgroundImage:[[UIImage 
                                           imageNamed:@"button.png"] 
                                          resizableImageWithCapInsets:UIEdgeInsetsMake(0, 12, 0,12)] 
                                forState:UIControlStateNormal];
    
    self.view.backgroundColor = [UIColor 
                                 colorWithPatternImage:[UIImage imageNamed:@"bg.png"]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionTapped
{
    if (self.deviceWasShaken)
    {
        FunActivity *funActivity = [[FunActivity alloc] init];
        
        NSString *initalTextString = [NSString
                                      stringWithFormat:@"Fun Fact: %@",
                                      self.factTextView.text];
        UIActivityViewController *activityViewController =
        [[UIActivityViewController alloc]
         initWithActivityItems:@[self.authorImageView.image,
         initalTextString]
         applicationActivities:@[funActivity]];
        [self presentViewController:activityViewController
                           animated:YES completion:nil];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Shake"
                                  message:@"Before you can share, please shake the device in order to get a random Fun Fact"
                                  delegate:nil
                                  cancelButtonTitle:@"Dismiss"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}

- (IBAction)socialTapped:(id)sender
{
    if (self.deviceWasShaken)
    {
        // 1
        NSString *serviceType = @"";
        
        // 2
        switch (((UIButton *)sender).tag)
        {
            case SocialButtonTagFacebook:
                serviceType = SLServiceTypeFacebook;
                break;
                
            case SocialButtonTagSinaWeibo:
                serviceType = SLServiceTypeSinaWeibo;
                break;
                
            case SocialButtonTagTwitter:
                serviceType = SLServiceTypeTwitter;
                break;
                
            default:
                break;
        }
        
        // 3
        if (![SLComposeViewController isAvailableForServiceType:serviceType])
        {
            // 4
            [self showUnavailableAlertForServiceType:serviceType];
        }
        else
        {
            // 5
            SLComposeViewController *composeViewController = [SLComposeViewController composeViewControllerForServiceType:serviceType];
            [composeViewController addImage:self.authorImageView.image];
            NSString *initalTextString = [NSString stringWithFormat:@"Fun Fact: %@", self.factTextView.text];
            [composeViewController setInitialText:initalTextString];
            [self presentViewController:composeViewController animated:YES completion:nil];
        }
    }
    else
    {
        // 6
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Shake"
                                                            message:@"Before you can share, please shake the device in order to get a random Fun Fact"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Dismiss"
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}

- (void)showUnavailableAlertForServiceType:
(NSString *)serviceType
{
    NSString *serviceName = @"";
    
    if (serviceType == SLServiceTypeFacebook)
    {
        serviceName = @"Facebook";
    }
    else if (serviceType == SLServiceTypeSinaWeibo)
    {
        serviceName = @"Sina Weibo";
    }
    else if (serviceType == SLServiceTypeTwitter)
    {
        serviceName = @"Twitter";
    }
    
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Account"
                              message:[NSString stringWithFormat:@"Please go to the device settings and add a %@ account in order to share through that service", serviceName]
                              delegate:nil
                              cancelButtonTitle:@"Dismiss"
                              otherButtonTitles:nil];
    [alertView show];
}


- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [self becomeFirstResponder];
}

- (NSArray *)authorsArray
{
    if (!_authorsArray)
    {
        NSString *authorsArrayPath = [[NSBundle mainBundle]
                                      pathForResource:@"FactsList" ofType:@"plist"];
        self.authorsArray = [NSArray
                             arrayWithContentsOfFile:authorsArrayPath];
    }
    
    return _authorsArray;
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    if (motion == UIEventSubtypeMotionShake)
    {
        self.deviceWasShaken = YES;
        
        NSUInteger authorRandSize = self.authorsArray.count;
        NSUInteger authorRandomIndex = (arc4random() % ((unsigned)authorRandSize));

        NSDictionary *authorDictionary = self.authorsArray[authorRandomIndex];

        NSArray *facts = authorDictionary[AuthorFactsKey];
        NSString *image = authorDictionary[AuthorImageKey];
        NSString *name = authorDictionary[AuthorNameKey];
        NSString *twitter = authorDictionary[AuthorTwitterKey];

        NSUInteger factsRandSize = facts.count;
        NSUInteger factsRandomIndex = (arc4random() % ((unsigned)factsRandSize));

        self.factTitleLabel.hidden = NO;

        self.factTextView.text = facts[factsRandomIndex];
        self.nameLabel.text = name;
        self.twitterLabel.text = twitter;
        self.authorImageView.image = [UIImage imageNamed:image];
    }
}


@end
