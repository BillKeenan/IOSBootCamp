//
//  RWViewController.h
//  FullScreenImageViewer
//
//  Created by Matt Galloway on 18/07/2012.
//  Copyright (c) 2012 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWViewController : UIViewController

- (void)openTextURL:(NSURL*)url;

@end
