
@interface EditViewController : UIViewController

@property (nonatomic, assign) int value;

@end
