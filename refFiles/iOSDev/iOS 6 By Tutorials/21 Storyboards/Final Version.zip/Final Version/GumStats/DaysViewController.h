
@class GraphViewController;

@interface DaysViewController : UITableViewController

@property (nonatomic, strong) GraphViewController *graphViewController;
@property (nonatomic, strong) NSArray *records;

@end
