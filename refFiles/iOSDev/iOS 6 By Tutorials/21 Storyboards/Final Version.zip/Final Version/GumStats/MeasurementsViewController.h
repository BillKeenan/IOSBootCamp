
@class Record;

@interface MeasurementsViewController : UITableViewController

@property (nonatomic, strong) Record *record;

@end
