
@interface CombinedViewController : UIViewController

@end
