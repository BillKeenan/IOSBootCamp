
@class Record;

@interface GraphViewController : UIViewController

@property (nonatomic, strong) Record *record;

@end
