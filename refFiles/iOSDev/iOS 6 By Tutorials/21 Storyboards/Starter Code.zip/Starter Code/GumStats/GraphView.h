
@interface GraphView : UIView

@property (nonatomic, strong) NSArray *values;
@property (nonatomic, assign) BOOL showCircles;

@end
