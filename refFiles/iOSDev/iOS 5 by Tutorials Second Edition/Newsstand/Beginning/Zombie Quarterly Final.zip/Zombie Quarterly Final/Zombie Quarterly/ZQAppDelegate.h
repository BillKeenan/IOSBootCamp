//
//  ZQAppDelegate.h
//  Zombie Quarterly
//
//  Created by Ray Wenderlich on 10/4/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
