//
//  main.m
//  Zombie Quarterly
//
//  Created by Ray Wenderlich on 10/4/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZQAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZQAppDelegate class]));
    }
}
