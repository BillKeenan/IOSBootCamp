//
//  ZQRssFeedFetcher.h
//  Zombie Quarterly
//
//  Created by Ray Wenderlich on 10/4/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZQPost.h"

@protocol ZQRssFeedFetcherDelegate <NSObject>
- (void)fetchFailed:(NSError *)error;
- (void)fetchSuccess:(NSArray *)posts;
@end

@interface ZQRssFeedFetcher : NSObject

- (id)initWithContentURL:(NSURL *)contentURL delegate:(id<ZQRssFeedFetcherDelegate>)delegate;
- (void)fetch;

@end
