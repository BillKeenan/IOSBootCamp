//
//  iPadViewController.m
//  Shortcuts
//
//  Created by Ray Wenderlich on 9/25/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import "iPadViewController.h"
#import "ShortcutsDatabase.h"
#import "DictionaryViewController.h"
#import "SearchableShortcutsViewController.h"
#import "FavoritesViewController.h"
#import "SettingsViewController.h"

@interface iPadViewController ()
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@end

@implementation iPadViewController {
    FavoritesViewController * _favorites;
    SettingsViewController * _settings;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_200.png"]];
    
    _favorites = [self.storyboard instantiateViewControllerWithIdentifier:@"Favorites"];
    _favorites.view.frame = self.bottomView.bounds;
    _favorites.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.bottomView addSubview:_favorites.view];
        
    _settings = [self.storyboard instantiateViewControllerWithIdentifier:@"Settings"];
    
    [self addChildViewController:_favorites];
    [_favorites didMoveToParentViewController:self];
    
}

- (IBAction)favoritesButtonTapped:(id)sender {
    [[ShortcutsDatabase sharedDatabase] playClick];
    [self addChildViewController:_favorites];
    [self transitionFromViewController:_settings
                      toViewController:_favorites
                              duration:0.5
                               options:UIViewAnimationOptionTransitionFlipFromBottom
                            animations:^{
        [_settings.view removeFromSuperview];
        _favorites.view.frame = self.bottomView.bounds;
        [self.bottomView addSubview:_favorites.view];
    } completion:^(BOOL finished) {
        [_favorites didMoveToParentViewController:self];
        [_settings removeFromParentViewController];
    }];
}

- (IBAction)settingsButtonTapped:(id)sender {
    [[ShortcutsDatabase sharedDatabase] playClick];
    [self addChildViewController:_settings];
    [self transitionFromViewController:_favorites
                      toViewController:_settings
                              duration:0.5
                               options:UIViewAnimationOptionTransitionFlipFromBottom
                            animations:^{
        [_favorites.view removeFromSuperview];
        _settings.view.frame = self.bottomView.bounds;
        [self.bottomView addSubview:_settings.view];
    } completion:^(BOOL finished) {
        [_settings didMoveToParentViewController:self];
        [_favorites removeFromParentViewController];
    }];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"ShortcutsByKey"]) {
        [[ShortcutsDatabase sharedDatabase] playClick];
        UINavigationController * navController = (UINavigationController *) segue.destinationViewController;
        DictionaryViewController * dictionaryViewController = navController.viewControllers[0];
        dictionaryViewController.navigationController.title = @"Keys";
        dictionaryViewController.dict = [ShortcutsDatabase sharedDatabase].shortcutsByKey;
    } else if ([segue.identifier isEqualToString:@"ShortcutsByMenu"]) {
        [[ShortcutsDatabase sharedDatabase] playClick];
        UINavigationController * navController = (UINavigationController *) segue.destinationViewController;
        DictionaryViewController * dictionaryViewController = navController.viewControllers[0];
        dictionaryViewController.navigationController.title = @"Menus";
        dictionaryViewController.dict = [ShortcutsDatabase sharedDatabase].shortcutsByMenu;
    } else if ([segue.identifier isEqualToString:@"AllShortcuts"]) {
        [[ShortcutsDatabase sharedDatabase] playClick];
        SearchableShortcutsViewController * shortcutsViewController = (SearchableShortcutsViewController *) segue.destinationViewController;
        shortcutsViewController.navigationItem.title = @"All Shortcuts";
        shortcutsViewController.shortcutsDict = [ShortcutsDatabase sharedDatabase].shortcutsByKey;
    }
}

@end
