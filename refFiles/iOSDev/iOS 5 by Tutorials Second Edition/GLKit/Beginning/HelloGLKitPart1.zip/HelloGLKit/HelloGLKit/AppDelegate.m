//
//  AppDelegate.m
//  HelloGLKit
//
//  Created by Ray Wenderlich on 9/24/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
    return YES;
}

@end
