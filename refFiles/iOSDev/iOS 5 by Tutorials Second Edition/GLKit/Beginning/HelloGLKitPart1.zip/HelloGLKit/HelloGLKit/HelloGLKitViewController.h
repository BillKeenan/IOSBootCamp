//
//  HelloGLKitViewController.h
//  HelloGLKit
//
//  Created by Ray Wenderlich on 9/24/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface HelloGLKitViewController : GLKViewController

@end
